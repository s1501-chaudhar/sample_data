output "storage_account_name" {
  value = azurerm_storage_account.app.name
}

output "storage_account_id" {
  value = azurerm_storage_account.app.id
}

output "containers" {
  value = [
    azurerm_storage_container.lab_reports.name,
    azurerm_storage_container.processed_data.name,
    azurerm_storage_container.progress_notes.name
  ]
}
