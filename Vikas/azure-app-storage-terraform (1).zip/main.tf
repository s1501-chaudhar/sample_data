resource "azurerm_storage_account" "app" {
  name                     = var.storage_account_name
  resource_group_name      = var.resource_group_name
  location                 = var.location
  account_tier             = "Standard"
  account_replication_type = "LRS"

  min_tls_version                 = "TLS1_2"
  public_network_access_enabled   = true
  allow_nested_items_to_be_public = false

  blob_properties {
    versioning_enabled = true
  }

  tags = {
    environment = "demo"
    purpose     = "application-storage"
  }
}

resource "azurerm_storage_container" "lab_reports" {
  name                  = "lab-reports"
  storage_account_id    = azurerm_storage_account.app.id
  container_access_type = "private"
}

resource "azurerm_storage_container" "processed_data" {
  name                  = "processed-data"
  storage_account_id    = azurerm_storage_account.app.id
  container_access_type = "private"
}

resource "azurerm_storage_container" "progress_notes" {
  name                  = "progress-notes"
  storage_account_id    = azurerm_storage_account.app.id
  container_access_type = "private"
}
