# Application Blob Storage

Creates one Azure Storage Account with three private Blob containers:

- lab-reports
- processed-data
- progress-notes

Blob versioning is enabled.

This is the APPLICATION storage account. Keep it separate from the
Storage Account used for Terraform remote state.

Run:
terraform init
terraform plan
terraform apply

Later we can add a Private Endpoint + Private DNS for this storage account.
