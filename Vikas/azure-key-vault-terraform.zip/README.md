# Azure Key Vault - Terraform

Creates:
- Azure Key Vault
- Private DNS Zone: privatelink.vaultcore.azure.net
- VNet link
- Private Endpoint in the existing 10.0.2.0/24 Private Endpoint subnet

No new VNet or subnet is created.

This step does NOT create secrets or Managed Identity/RBAC.
Those will be handled separately.

Run:
terraform init
terraform fmt
terraform validate
terraform plan
terraform apply

Review terraform plan before applying.
