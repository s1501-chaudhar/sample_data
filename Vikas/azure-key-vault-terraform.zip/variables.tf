variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "tenant_id" {
  type        = string
  description = "Microsoft Entra tenant ID"
}

variable "key_vault_name" {
  type        = string
  description = "Globally unique Key Vault name"
}

variable "vnet_id" {
  type        = string
  description = "Existing VNet resource ID"
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Existing Private Endpoint subnet resource ID (10.0.2.0/24)"
}
