output "key_vault_id" {
  value = azurerm_key_vault.app.id
}

output "key_vault_uri" {
  value = azurerm_key_vault.app.vault_uri
}

output "private_endpoint_id" {
  value = azurerm_private_endpoint.key_vault.id
}

output "private_endpoint_ip" {
  value = azurerm_private_endpoint.key_vault.private_service_connection[0].private_ip_address
}

output "private_dns_zone" {
  value = azurerm_private_dns_zone.key_vault.name
}
