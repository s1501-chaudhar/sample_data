output "document_intelligence_id" {
  value = azurerm_cognitive_account.document_intelligence.id
}

output "document_intelligence_endpoint" {
  value = azurerm_cognitive_account.document_intelligence.endpoint
}

output "private_endpoint_id" {
  value = azurerm_private_endpoint.document_intelligence.id
}

output "private_endpoint_ip" {
  value = azurerm_private_endpoint.document_intelligence.private_service_connection[0].private_ip_address
}

output "private_dns_zone" {
  value = azurerm_private_dns_zone.document_intelligence.name
}
