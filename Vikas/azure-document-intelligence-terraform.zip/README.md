# Azure AI Document Intelligence - Terraform

This Terraform project creates Azure AI Document Intelligence and its
private connectivity.

Resources created:

1. Azure AI Document Intelligence
2. Private DNS Zone
   `privatelink.cognitiveservices.azure.com`
3. Private DNS Zone -> existing VNet link
4. Private Endpoint in the EXISTING Private Endpoint subnet
   `10.0.2.0/24`

No new VNet or subnet is created.

Architecture:

Storage / Function / Backend
          |
          | VNet
          v
Private Endpoint Subnet
10.0.2.0/24
          |
          v
Private Endpoint
          |
          v
Document Intelligence

IMPORTANT:
- This is for extracting information from uploaded lab reports.
- It is NOT a RAG component.
- This step creates the Azure resource and private connectivity.
- It does not create a model deployment or application code.

Commands:

terraform init
terraform fmt
terraform validate
terraform plan
terraform apply

Always review `terraform plan` before applying.
