# Azure AI Document Intelligence
resource "azurerm_cognitive_account" "document_intelligence" {
  name                = var.document_intelligence_name
  location            = var.location
  resource_group_name = var.resource_group_name

  kind     = "FormRecognizer"
  sku_name = "S0"

  custom_subdomain_name = var.document_intelligence_name

  public_network_access_enabled = false

  tags = {
    environment = "demo"
    purpose     = "lab-report-extraction"
  }
}

# Private DNS zone for Azure Cognitive Services
resource "azurerm_private_dns_zone" "document_intelligence" {
  name                = "privatelink.cognitiveservices.azure.com"
  resource_group_name = var.resource_group_name
}

# Link Private DNS zone to existing VNet
resource "azurerm_private_dns_zone_virtual_network_link" "document_intelligence" {
  name                  = "document-intelligence-dns-vnet-link"
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.document_intelligence.name
  virtual_network_id    = var.vnet_id
}

# Private Endpoint in the EXISTING Private Endpoint subnet
resource "azurerm_private_endpoint" "document_intelligence" {
  name                = "document-intelligence-private-endpoint"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id

  private_service_connection {
    name                           = "document-intelligence-private-connection"
    private_connection_resource_id = azurerm_cognitive_account.document_intelligence.id
    is_manual_connection           = false
    subresource_names              = ["account"]
  }

  private_dns_zone_group {
    name = "document-intelligence-dns-zone-group"

    private_dns_zone_ids = [
      azurerm_private_dns_zone.document_intelligence.id
    ]
  }
}
