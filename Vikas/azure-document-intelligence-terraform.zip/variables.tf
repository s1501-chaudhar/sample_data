variable "subscription_id" {
  type        = string
  description = "Azure Subscription ID"
}

variable "resource_group_name" {
  type        = string
  description = "Existing Azure Resource Group"
}

variable "location" {
  type        = string
  description = "Azure region"
}

variable "document_intelligence_name" {
  type        = string
  description = "Globally unique Azure Document Intelligence account name"
}

variable "vnet_id" {
  type        = string
  description = "Existing VNet resource ID"
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Existing Private Endpoint subnet resource ID (10.0.2.0/24)"
}
