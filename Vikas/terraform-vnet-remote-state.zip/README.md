Terraform VNet Project

Creates:
- VNet (10.0.0.0/16)
- appservice-integration-subnet (10.0.1.0/24)
- private-endpoint-subnet (10.0.2.0/24)

Remote Backend:
Storage Account : capstonetfstate001
Container       : tfstate
State File      : network/terraform.tfstate

Commands:
terraform init
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars
