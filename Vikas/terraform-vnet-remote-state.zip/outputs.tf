output "vnet_id" {
  value = azurerm_virtual_network.vnet.id
}

output "appservice_subnet_id" {
  value = azurerm_subnet.appservice.id
}

output "private_endpoint_subnet_id" {
  value = azurerm_subnet.private_endpoint.id
}
