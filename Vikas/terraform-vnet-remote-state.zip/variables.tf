variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
}

variable "resource_group_name" {
  default = "GenAI-B5-Project-T5-RG"
}

variable "location" {
  default = "Central US"
}

variable "vnet_name" {
  default = "capstone-vnet"
}
