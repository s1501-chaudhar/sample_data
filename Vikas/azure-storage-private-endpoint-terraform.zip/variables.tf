variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "vnet_id" {
  type        = string
  description = "Existing VNet resource ID"
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Existing Private Endpoint subnet resource ID (10.0.2.0/24)"
}

variable "storage_account_id" {
  type        = string
  description = "Existing application Storage Account resource ID"
}
