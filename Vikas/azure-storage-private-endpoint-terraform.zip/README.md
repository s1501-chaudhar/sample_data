# Azure Storage Private Endpoint - Terraform

Creates private connectivity from the existing VNet to the existing
application Blob Storage account.

Creates:
- Private DNS Zone: privatelink.blob.core.windows.net
- Private DNS Zone to VNet link
- Private Endpoint in the existing 10.0.2.0/24 subnet

Does NOT create another VNet, subnet, or Storage Account.

Run:
terraform init
terraform fmt
terraform validate
terraform plan
terraform apply

Check the plan before apply. It should create only the Private DNS Zone,
VNet link, and Storage Private Endpoint.
