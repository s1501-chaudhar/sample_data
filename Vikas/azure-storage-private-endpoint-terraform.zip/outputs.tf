output "private_endpoint_id" {
  value = azurerm_private_endpoint.storage_blob.id
}

output "private_endpoint_ip" {
  value = azurerm_private_endpoint.storage_blob.private_service_connection[0].private_ip_address
}

output "private_dns_zone" {
  value = azurerm_private_dns_zone.blob.name
}
