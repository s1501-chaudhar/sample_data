variable "resource_group_name"{
  default="GenAI-B5-Project-T5-RG"
}

variable "location"{
  default="Central US"
}

variable "storage_account_name"{
  default="capstonetfstate001"
  # Storage account names must be globally unique.
}

variable "container_name"{
  default="tfstate"
}
