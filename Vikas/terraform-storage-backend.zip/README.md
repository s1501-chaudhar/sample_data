Run:
terraform init
terraform plan
terraform apply

This creates:
- Storage Account
- Private Blob Container (tfstate)
- Blob versioning enabled

NOTE:
If 'capstonetfstate001' is already taken globally, change storage_account_name in variables.tf.
