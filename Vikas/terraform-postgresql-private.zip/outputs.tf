output "postgresql_server_id" {
  value = azurerm_postgresql_flexible_server.postgresql.id
}

output "postgresql_fqdn" {
  value = azurerm_postgresql_flexible_server.postgresql.fqdn
}

output "postgresql_subnet_id" {
  value = azurerm_subnet.postgresql.id
}
