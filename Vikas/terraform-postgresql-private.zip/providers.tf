terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }

  backend "azurerm" {
    subscription_id      = "<YOUR_SUBSCRIPTION_ID>"
    resource_group_name  = "GenAI-B5-Project-T5-RG"
    storage_account_name = "<YOUR_EXISTING_STATE_STORAGE_ACCOUNT>"
    container_name       = "tfstate"
    key                  = "postgresql/terraform.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}
