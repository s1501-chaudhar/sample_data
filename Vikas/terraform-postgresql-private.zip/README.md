# Private PostgreSQL Terraform Step

Creates:
- PostgreSQL delegated subnet: 10.0.3.0/24
- Private DNS zone and VNet link
- PostgreSQL Flexible Server
- Public network access disabled

IMPORTANT:
Do NOT reuse the 10.0.2.0/24 private-endpoint subnet for this PostgreSQL
Flexible Server. VNet-injected PostgreSQL requires its own delegated subnet.

Remote state:
tfstate/postgresql/terraform.tfstate

Run:
terraform init
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars

Do not commit terraform.tfvars or passwords to Git.
