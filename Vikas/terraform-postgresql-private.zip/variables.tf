variable "subscription_id" {
  type = string
}

variable "resource_group_name" {
  type    = string
  default = "GenAI-B5-Project-T5-RG"
}

variable "location" {
  type    = string
  default = "Central US"
}

variable "vnet_name" {
  type    = string
  default = "capstone-vnet"
}

variable "vnet_id" {
  description = "Resource ID of the existing VNet"
  type        = string
}

variable "postgresql_server_name" {
  type    = string
  default = "capstone-pg-demo-001"
}

variable "admin_username" {
  type      = string
  sensitive = true
}

variable "admin_password" {
  type      = string
  sensitive = true
}
