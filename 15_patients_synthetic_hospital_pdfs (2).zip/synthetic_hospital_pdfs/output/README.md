# Synthetic Clinical PDF Dataset

All documents in this folder are **fully synthetic**. Institutions, providers, patients, MRNs, CLIA numbers, and results are fictional and generated for document-intelligence pipeline development (OCR / extraction / RAG). They must not be represented as genuine medical records.

Regenerate with: `python dataset/pdf_generator/generate_hospital_pdfs.py`
