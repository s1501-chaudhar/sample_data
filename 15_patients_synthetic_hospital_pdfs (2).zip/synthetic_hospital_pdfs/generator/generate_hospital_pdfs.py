"""
Synthetic hospital document generator (production-grade layout).

Generates fully synthetic — but visually authentic — clinical PDFs styled after
US hospital LIS/EHR output (reference-lab style laboratory reports, radiology
reports, and EHR-style clinical notes). All institutions, providers, patients,
identifiers, and CLIA numbers are FICTIONAL. Documents are vector-text PDFs
(OCR-friendly, fully selectable) intended for document-intelligence pipelines.

Output: ../output/<PATIENT_ID>_<DX>/<doc>.pdf  + manifest.csv
This is a standalone dataset generator — independent of any other project's dataset folder.
"""

import csv
import os
from functools import partial

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import (
    BaseDocTemplate, Frame, KeepTogether, PageTemplate, Paragraph, Spacer,
    Table, TableStyle,
)
from reportlab.graphics.barcode import code128
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF

PAGE_W, PAGE_H = letter
MARGIN = 40
BODY_W = PAGE_W - 2 * MARGIN

OUT_ROOT = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "output"))

GRAY_LABEL = colors.HexColor("#5A6068")
GRAY_LINE = colors.HexColor("#B9BEC4")
GRAY_BAND = colors.HexColor("#E8EAED")
GRAY_ALT = colors.HexColor("#F5F6F8")
FLAG_RED = colors.HexColor("#9E1B1B")
INK = colors.HexColor("#1A1C1F")

# ----------------------------------------------------------------------------
# Fictional institutions
# ----------------------------------------------------------------------------
MERIDIAN = {
    "name": "MERIDIAN REGIONAL MEDICAL CENTER",
    "addr": "4200 Ashworth Parkway, Columbus, OH 43215",
    "phone": "Tel (614) 555-0142",
    "fax": "Fax (614) 555-0143",
    "web": "www.meridianregional.org",
    "clia": "CLIA: 36D2071455",
    "lab_dir": "Rachel T. Okafor, MD, PhD",
    "lab_name": "MRMC Core Laboratory",
    "color": colors.HexColor("#0B5B63"),
    "tech": "Meredith L. Chan, MT(ASCP)",
}
ASHFORD = {
    "name": "ASHFORD UNIVERSITY MEDICAL CENTER",
    "addr": "1150 College Hill Drive, Richmond, VA 23219",
    "phone": "Tel (804) 555-0173",
    "fax": "Fax (804) 555-0174",
    "web": "www.ashfordumc.edu",
    "clia": "CLIA: 49D1988203",
    "lab_dir": "Howard M. Feinstein, MD",
    "lab_name": "AUMC Clinical Laboratories",
    "color": colors.HexColor("#1F3A6E"),
    "tech": "Jordan A. Reyes, MLS(ASCP)",
}

# ----------------------------------------------------------------------------
# Shared paragraph styles
# ----------------------------------------------------------------------------
S_BODY = ParagraphStyle("body", fontName="Helvetica", fontSize=9, leading=11.8,
                        textColor=INK, spaceAfter=5)
S_SMALL = ParagraphStyle("small", fontName="Helvetica", fontSize=7.5, leading=9.4,
                         textColor=colors.HexColor("#3C4046"), spaceAfter=3)
S_COMMENT = ParagraphStyle("comment", fontName="Helvetica-Oblique", fontSize=7.5,
                           leading=9.4, textColor=colors.HexColor("#3C4046"),
                           leftIndent=6, spaceAfter=2)
S_SECHEAD = ParagraphStyle("sechead", fontName="Helvetica-Bold", fontSize=9.5,
                           leading=12, textColor=INK, spaceBefore=8, spaceAfter=3)
S_BULLET = ParagraphStyle("bullet", parent=S_BODY, leftIndent=14, spaceAfter=2,
                          bulletIndent=4)
S_SIG = ParagraphStyle("sig", fontName="Helvetica", fontSize=8, leading=10.4,
                       textColor=INK, spaceAfter=1)
S_CELL = ParagraphStyle("cell", fontName="Helvetica", fontSize=8.1, leading=9.8, textColor=INK)
S_CELL_FLAG = ParagraphStyle("cell_flag", parent=S_CELL, fontName="Helvetica-Bold")
S_CELL_RESULT = ParagraphStyle("cell_result", parent=S_CELL)
S_CELL_RESULT_FLAG = ParagraphStyle("cell_result_flag", parent=S_CELL,
                                    fontName="Helvetica-Bold", textColor=FLAG_RED)


# ----------------------------------------------------------------------------
# Canvas with "Page X of Y"
# ----------------------------------------------------------------------------
class NumberedCanvas(rl_canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_states = []

    def showPage(self):
        self._saved_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved_states)
        for state in self._saved_states:
            self.__dict__.update(state)
            self.setFont("Helvetica", 7)
            self.setFillColor(GRAY_LABEL)
            self.drawRightString(PAGE_W - MARGIN, 34, f"Page {self._pageNumber} of {total}")
            super().showPage()
        super().save()


# ----------------------------------------------------------------------------
# Drawing helpers
# ----------------------------------------------------------------------------
def draw_logo(c, x, y, size, color):
    c.saveState()
    c.setFillColor(color)
    c.roundRect(x, y, size, size, size * 0.18, fill=1, stroke=0)
    c.setFillColor(colors.white)
    cw = size * 0.20
    ln = size * 0.62
    cx, cy = x + size / 2.0, y + size / 2.0
    c.rect(cx - cw / 2, cy - ln / 2, cw, ln, fill=1, stroke=0)
    c.rect(cx - ln / 2, cy - cw / 2, ln, cw, fill=1, stroke=0)
    c.setStrokeColor(colors.white)
    c.setLineWidth(size * 0.045)
    c.arc(x + size * 0.10, y + size * 0.10, x + size * 0.90, y + size * 0.90, 300, 120)
    c.restoreState()


def draw_qr(c, data, x, y, size):
    qr = QrCodeWidget(data, barLevel="M")
    b = qr.getBounds()
    w, h = b[2] - b[0], b[3] - b[1]
    d = Drawing(size, size, transform=[size / w, 0, 0, size / h, 0, 0])
    d.add(qr)
    renderPDF.draw(d, c, x, y)


def draw_grid(c, grid, x, y_top, width, n_cols=4, row_h=22.5):
    """Label-over-value demographics grid, LIS style."""
    n_rows = (len(grid) + n_cols - 1) // n_cols
    col_w = width / n_cols
    box_h = n_rows * row_h + 4
    c.saveState()
    c.setStrokeColor(GRAY_LINE)
    c.setLineWidth(0.5)
    c.rect(x, y_top - box_h, width, box_h, fill=0, stroke=1)
    for r in range(1, n_rows):
        yy = y_top - r * row_h - 2
        c.line(x, yy, x + width, yy)
    avail_w = col_w - 8
    for i, (label, value) in enumerate(grid):
        r, col = divmod(i, n_cols)
        cx = x + col * col_w + 5
        cy = y_top - r * row_h - 2
        c.setFont("Helvetica-Bold", 6.2)
        c.setFillColor(GRAY_LABEL)
        c.drawString(cx, cy - 8, label.upper())
        c.setFillColor(INK)
        text = str(value)
        size = 8.2
        while size > 5.6 and c.stringWidth(text, "Helvetica", size) > avail_w:
            size -= 0.4
        if c.stringWidth(text, "Helvetica", size) > avail_w:
            while text and c.stringWidth(text + "...", "Helvetica", size) > avail_w:
                text = text[:-1]
            text = (text + "...") if text != str(value) else text
        c.setFont("Helvetica", size)
        c.drawString(cx, cy - 18, text)
    c.restoreState()
    return box_h


def draw_footer(c, hosp, meta):
    c.saveState()
    c.setStrokeColor(GRAY_LINE)
    c.setLineWidth(0.6)
    c.line(MARGIN, 56, PAGE_W - MARGIN, 56)
    c.setFont("Helvetica", 7)
    c.setFillColor(GRAY_LABEL)
    c.drawString(MARGIN, 46, f"{hosp['name'].title()}  |  {hosp['addr']}  |  {hosp['clia']}")
    c.drawString(MARGIN, 37,
                 "This document contains confidential protected health information. "
                 "Unauthorized review, use, or disclosure is prohibited.")
    c.drawString(MARGIN, 28, f"Printed: {meta['printed']}   Document ID: {meta['docid']}")
    c.drawRightString(PAGE_W - MARGIN, 46, meta.get("footer_right", "Electronically generated report"))
    c.restoreState()


def draw_report_page(c, doc, hosp, pt, meta):
    """Full LIS-style header for lab / radiology reports (repeats each page)."""
    c.saveState()
    # --- masthead
    draw_logo(c, MARGIN, 736, 36, hosp["color"])
    c.setFillColor(hosp["color"])
    c.setFont("Helvetica-Bold", 14.5)
    c.drawString(MARGIN + 44, 758, hosp["name"])
    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(GRAY_LABEL)
    c.drawString(MARGIN + 44, 747, meta["department"])
    c.setFont("Helvetica", 7.3)
    c.drawString(MARGIN + 44, 738, f"{hosp['addr']}   {hosp['phone']}   {hosp['fax']}   {hosp['web']}")
    c.drawString(MARGIN + 44, 729, f"{hosp['clia']}   Laboratory Director: {hosp['lab_dir']}")

    # --- report type + status box (right)
    c.setFont("Helvetica-Bold", 10)
    c.setFillColor(INK)
    c.drawRightString(PAGE_W - MARGIN, 758, meta["doctype"])
    c.setStrokeColor(hosp["color"])
    c.setLineWidth(0.9)
    c.setFillColor(colors.white)
    c.rect(PAGE_W - MARGIN - 92, 736, 92, 15, fill=1, stroke=1)
    c.setFillColor(hosp["color"])
    c.setFont("Helvetica-Bold", 8.5)
    c.drawCentredString(PAGE_W - MARGIN - 46, 740.5, meta["status"])

    # --- barcode of accession (right, under status)
    bc = code128.Code128(meta["accession"], barHeight=15, barWidth=0.82, humanReadable=0)
    bc.drawOn(c, PAGE_W - MARGIN - bc.width, 712)
    c.setFont("Helvetica", 6.5)
    c.setFillColor(INK)
    c.drawRightString(PAGE_W - MARGIN, 705, meta["accession"])

    # --- divider
    c.setStrokeColor(hosp["color"])
    c.setLineWidth(1.6)
    c.line(MARGIN, 700, PAGE_W - MARGIN, 700)
    c.setLineWidth(0.5)
    c.line(MARGIN, 697.4, PAGE_W - MARGIN, 697.4)

    # --- demographics grid + QR
    qr_size = 46
    grid_w = BODY_W - qr_size - 10
    grid_box_h = draw_grid(c, meta["grid"], MARGIN, 692, grid_w, n_cols=4)
    grid_bottom = 692 - grid_box_h
    qr_data = (f"PT:{pt['last']}^{pt['first']}|MRN:{pt['mrn']}|DOB:{pt['dob_iso']}"
               f"|ACC:{meta['accession']}|ENC:{meta['encounter']}")
    draw_qr(c, qr_data, PAGE_W - MARGIN - qr_size, 692 - qr_size, qr_size)
    c.setFont("Helvetica", 5.6)
    c.setFillColor(GRAY_LABEL)
    c.drawCentredString(PAGE_W - MARGIN - qr_size / 2, 692 - qr_size - 7, "SCAN FOR CHART")

    c.setStrokeColor(GRAY_LINE)
    c.setLineWidth(0.6)
    c.line(MARGIN, grid_bottom - 6, PAGE_W - MARGIN, grid_bottom - 6)
    c.restoreState()
    draw_footer(c, hosp, meta)


def draw_note_page(c, doc, hosp, pt, meta):
    """EHR-style header for clinical notes (banner + patient strip)."""
    c.saveState()
    # brand bar
    c.setFillColor(hosp["color"])
    c.rect(0, 756, PAGE_W, 36, fill=1, stroke=0)
    draw_logo(c, MARGIN, 761, 26, colors.white)
    # redraw cross in brand color over white logo tile
    c.setFillColor(hosp["color"])
    cw, ln = 26 * 0.20, 26 * 0.62
    cx, cy = MARGIN + 13, 761 + 13
    c.rect(cx - cw / 2, cy - ln / 2, cw, ln, fill=1, stroke=0)
    c.rect(cx - ln / 2, cy - cw / 2, ln, cw, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 12.5)
    c.drawString(MARGIN + 34, 774, hosp["name"])
    c.setFont("Helvetica", 7.2)
    c.drawString(MARGIN + 34, 763, f"{hosp['addr']}   {hosp['phone']}   {hosp['web']}")
    c.setFont("Helvetica-Bold", 8)
    c.drawRightString(PAGE_W - MARGIN, 774, "ELECTRONIC HEALTH RECORD")
    c.setFont("Helvetica", 7.2)
    c.drawRightString(PAGE_W - MARGIN, 763, meta["department"])

    # patient banner strip
    c.setFillColor(GRAY_BAND)
    c.rect(MARGIN, 726, BODY_W, 24, fill=1, stroke=0)
    c.setFillColor(INK)
    c.setFont("Helvetica-Bold", 9.5)
    c.drawString(MARGIN + 6, 735.5, f"{pt['last']}, {pt['first']}")
    c.setFont("Helvetica", 8)
    c.drawString(MARGIN + 170, 735.5,
                 f"MRN: {pt['mrn']}    DOB: {pt['dob']} ({pt['age']} yo {pt['sex']})    "
                 f"CSN: {meta['encounter']}")
    c.setFont("Helvetica", 7.2)
    c.setFillColor(GRAY_LABEL)
    c.drawString(MARGIN + 6, 728,
                 f"Attending: {meta['attending']}    Unit/Clinic: {meta['unit']}    "
                 f"Allergies: {pt['allergies']}")

    # note title
    c.setFillColor(INK)
    c.setFont("Helvetica-Bold", 11)
    c.drawString(MARGIN, 708, meta["note_title"])
    c.setFont("Helvetica", 8)
    c.setFillColor(GRAY_LABEL)
    c.drawRightString(PAGE_W - MARGIN, 708, f"Service Date: {meta['service_date']}    Status: {meta['status']}")
    c.setStrokeColor(hosp["color"])
    c.setLineWidth(1.1)
    c.line(MARGIN, 702, PAGE_W - MARGIN, 702)

    # faint watermark
    c.setFillColor(colors.Color(0.945, 0.948, 0.952))
    c.setFont("Helvetica-Bold", 30)
    c.saveState()
    c.translate(PAGE_W / 2, PAGE_H / 2 - 40)
    c.rotate(36)
    c.drawCentredString(0, 0, "OFFICIAL RECORD COPY")
    c.restoreState()
    c.restoreState()
    draw_footer(c, hosp, meta)


# ----------------------------------------------------------------------------
# Flowable builders
# ----------------------------------------------------------------------------
def panel_flowables(hosp, panel):
    """One results panel: section band + results table + comments."""
    flows = []
    band = Table(
        [[panel["name"], panel.get("performed", f"Performing Site: {hosp['lab_name']}")]],
        colWidths=[BODY_W * 0.62, BODY_W * 0.38])
    band.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), hosp["color"]),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
        ("FONTNAME", (0, 0), (0, 0), "Helvetica-Bold"),
        ("FONTNAME", (1, 0), (1, 0), "Helvetica"),
        ("FONTSIZE", (0, 0), (0, 0), 8.6),
        ("FONTSIZE", (1, 0), (1, 0), 6.8),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    flows.append(band)

    header = ["TEST", "RESULT", "FLAG", "UNITS", "REFERENCE INTERVAL"]
    rows = [header]
    flagged = []
    for i, (test, result, flag, units, ref) in enumerate(panel["tests"], start=1):
        test_style = S_CELL_FLAG if flag else S_CELL
        result_style = S_CELL_RESULT_FLAG if flag else S_CELL_RESULT
        rows.append([Paragraph(str(test), test_style), Paragraph(str(result), result_style),
                     flag, units, ref])
        if flag:
            flagged.append(i)
    tbl = Table(rows, colWidths=[BODY_W * 0.365, BODY_W * 0.135, BODY_W * 0.06,
                                 BODY_W * 0.14, BODY_W * 0.30], repeatRows=1)
    style = [
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 7.2),
        ("BACKGROUND", (0, 0), (-1, 0), GRAY_BAND),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#2A2E33")),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 1), (-1, -1), 8.1),
        ("TEXTCOLOR", (0, 1), (-1, -1), INK),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, GRAY_ALT]),
        ("GRID", (0, 0), (-1, -1), 0.4, GRAY_LINE),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.HexColor("#8A9096")),
        ("ALIGN", (2, 0), (2, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, -1), 2.6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ]
    for r in flagged:
        style += [
            ("FONTNAME", (2, r), (2, r), "Helvetica-Bold"),
            ("TEXTCOLOR", (2, r), (2, r), FLAG_RED),
        ]
    tbl.setStyle(TableStyle(style))
    flows.append(tbl)

    for cm in panel.get("comments", []):
        flows.append(Paragraph(cm, S_COMMENT))
    flows.append(Spacer(1, 9))
    return flows


def lab_signoff_flowables(hosp, meta):
    flows = [Spacer(1, 6)]
    S_SPEC = ParagraphStyle("spec", fontName="Helvetica", fontSize=7.4, leading=9,
                            textColor=colors.HexColor("#3C4046"))
    spec_rows = [[
        Paragraph(f"Specimen: {meta['specimen']}", S_SPEC),
        Paragraph(f"Specimen ID: {meta['specimen_id']}", S_SPEC),
        Paragraph(f"Collected: {meta['collected']}", S_SPEC),
    ], [
        Paragraph(f"Received: {meta['received']}", S_SPEC),
        Paragraph(f"Reported: {meta['reported']}", S_SPEC),
        Paragraph(f"Fasting: {meta.get('fasting', 'N')}", S_SPEC),
    ]]
    spec = Table(spec_rows, colWidths=[BODY_W / 3.0] * 3)
    spec.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.5, GRAY_LINE),
        ("LINEBELOW", (0, 0), (-1, 0), 0.4, GRAY_LINE),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ]))
    flows.append(KeepTogether([
        Paragraph("<b>SPECIMEN INFORMATION</b>", S_SMALL), spec, Spacer(1, 8),
        Paragraph("*** END OF REPORT ***",
                  ParagraphStyle("eor", fontName="Helvetica-Bold", fontSize=8.5,
                                 alignment=1, textColor=INK, spaceAfter=8)),
        Paragraph(f"Performing Laboratory: {hosp['lab_name']}, {hosp['addr']}  |  {hosp['clia']}", S_SIG),
        Paragraph(f"Electronically verified and released by: <b>{hosp['tech']}</b>   {meta['reported']}", S_SIG),
        Paragraph(f"Laboratory Director: <b>{hosp['lab_dir']}</b>", S_SIG),
        Paragraph("This report has been electronically signed and released by the laboratory "
                  "information system in accordance with CLIA §493.1291. "
                  "Reference intervals apply to the adult population unless otherwise noted.", S_SMALL),
    ]))
    return flows


def build_report_pdf(path, hosp, pt, meta, story):
    doc = BaseDocTemplate(path, pagesize=letter, leftMargin=MARGIN, rightMargin=MARGIN,
                          title=meta["doctype"], author=hosp["name"].title())
    frame = Frame(MARGIN, 66, BODY_W, 526, leftPadding=0, rightPadding=0,
                  topPadding=4, bottomPadding=0, id="body")
    doc.addPageTemplates([PageTemplate(
        id="main", frames=[frame],
        onPage=partial(draw_report_page, hosp=hosp, pt=pt, meta=meta))])
    doc.build(story, canvasmaker=NumberedCanvas)


def build_note_pdf(path, hosp, pt, meta, story):
    doc = BaseDocTemplate(path, pagesize=letter, leftMargin=MARGIN, rightMargin=MARGIN,
                          title=meta["note_title"], author=hosp["name"].title())
    frame = Frame(MARGIN, 66, BODY_W, 630, leftPadding=0, rightPadding=0,
                  topPadding=6, bottomPadding=0, id="body")
    doc.addPageTemplates([PageTemplate(
        id="main", frames=[frame],
        onPage=partial(draw_note_page, hosp=hosp, pt=pt, meta=meta))])
    doc.build(story, canvasmaker=NumberedCanvas)


def note_story(sections, sig_lines):
    flows = []
    for heading, content in sections:
        flows.append(Paragraph(heading.upper(), S_SECHEAD))
        if isinstance(content, str):
            for para in content.split("\n\n"):
                flows.append(Paragraph(para, S_BODY))
        elif isinstance(content, list):
            for item in content:
                flows.append(Paragraph(item, S_BULLET, bulletText="•"))
        elif isinstance(content, dict) and "table" in content:
            headers, rows, widths = content["table"]
            data = [headers] + rows
            t = Table(data, colWidths=[BODY_W * w for w in widths], repeatRows=1)
            t.setStyle(TableStyle([
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 7.4),
                ("BACKGROUND", (0, 0), (-1, 0), GRAY_BAND),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 1), (-1, -1), 8.2),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, GRAY_ALT]),
                ("GRID", (0, 0), (-1, -1), 0.4, GRAY_LINE),
                ("TOPPADDING", (0, 0), (-1, -1), 2.6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ]))
            flows.append(t)
            flows.append(Spacer(1, 4))
    sig = [Spacer(1, 14),
           Table([[""]], colWidths=[BODY_W], style=TableStyle(
               [("LINEABOVE", (0, 0), (-1, 0), 0.6, GRAY_LINE)]))]
    for ln in sig_lines:
        sig.append(Paragraph(ln, S_SIG))
    flows.append(KeepTogether(sig))
    return flows


def radiology_story(fields, impression, sig_lines):
    flows = []
    for label, text in fields:
        flows.append(Paragraph(label.upper(), S_SECHEAD))
        for para in text.split("\n\n"):
            flows.append(Paragraph(para, S_BODY))
    flows.append(Paragraph("IMPRESSION", S_SECHEAD))
    for i, item in enumerate(impression, 1):
        flows.append(Paragraph(f"{i}.  {item}", S_BODY))
    sig = [Spacer(1, 14),
           Table([[""]], colWidths=[BODY_W], style=TableStyle(
               [("LINEABOVE", (0, 0), (-1, 0), 0.6, GRAY_LINE)]))]
    for ln in sig_lines:
        sig.append(Paragraph(ln, S_SIG))
    flows.append(KeepTogether(sig))
    return flows


# ----------------------------------------------------------------------------
# Meta helpers
# ----------------------------------------------------------------------------
def report_grid(pt, meta):
    return [
        ("Patient Name", f"{pt['last']}, {pt['first']}"),
        ("DOB / Age / Sex", f"{pt['dob']} / {pt['age']} yrs / {pt['sex']}"),
        ("MRN", pt["mrn"]),
        ("Accession #", meta["accession"]),
        ("Visit #", meta["visit"]),
        ("Encounter ID", meta["encounter"]),
        ("Patient Phone", pt["phone"]),
        (meta.get("g8_label", "Specimen Type"), meta.get("g8_value", meta.get("specimen", ""))),
        ("Ordering Physician", meta["ordering"]),
        ("Attending Physician", meta["attending"]),
        ("Client #", meta["client"]),
        ("Report Status", meta["status"]),
        ("Collected", meta["collected"]),
        ("Received", meta["received"]),
        ("Reported", meta["reported"]),
        ("Printed", meta["printed"]),
    ]


def mk_meta(pt, base, **kw):
    meta = dict(base)
    meta.update(kw)
    meta.setdefault("printed", meta["reported"])
    meta.setdefault("footer_right", "Report generated by LIS v11.4.2")
    meta.setdefault("docid", meta.get("accession", ""))
    meta["grid"] = report_grid(pt, meta)
    return meta


# ============================================================================
# PATIENTS & CASES
# ============================================================================
P001 = dict(last="WALSH", first="GREGORY A", sex="M", dob="03/14/1968", dob_iso="1968-03-14",
            age=58, mrn="000482913", phone="(614) 555-2871", allergies="NKDA")
P002 = dict(last="OKONKWO", first="MARGARET E", sex="F", dob="09/02/1958", dob_iso="1958-09-02",
            age=67, mrn="001127465", phone="(804) 555-6134", allergies="Sulfa (rash)")
P003 = dict(last="DELGADO", first="RICARDO M", sex="M", dob="11/21/1964", dob_iso="1964-11-21",
            age=61, mrn="000914327", phone="(804) 555-9082", allergies="NKDA")
P004 = dict(last="TRAN", first="LINH H", sex="F", dob="05/09/1974", dob_iso="1974-05-09",
            age=52, mrn="001338276", phone="(614) 555-4417", allergies="Penicillin (hives)")
P005 = dict(last="KOWALSKI", first="ALBERT J", sex="M", dob="01/27/1952", dob_iso="1952-01-27",
            age=74, mrn="000765481", phone="(804) 555-3320", allergies="NKDA")
P006 = dict(last="HAYES", first="DOROTHY M", sex="F", dob="04/02/1951", dob_iso="1951-04-02",
            age=75, mrn="000551829", phone="(614) 555-7743", allergies="NKDA")
P007 = dict(last="MCALLISTER", first="DENNIS R", sex="M", dob="08/19/1957", dob_iso="1957-08-19",
            age=68, mrn="000998214", phone="(804) 555-2216", allergies="NKDA")
P008 = dict(last="FIGUEROA", first="CARMEN L", sex="F", dob="02/11/1979", dob_iso="1979-02-11",
            age=47, mrn="000672390", phone="(614) 555-8801", allergies="NKDA")
P009 = dict(last="NGUYEN", first="MINH T", sex="M", dob="06/25/1990", dob_iso="1990-06-25",
            age=36, mrn="001045782", phone="(804) 555-4429", allergies="NKDA")
P010 = dict(last="BARNES", first="ELEANOR J", sex="F", dob="12/03/1948", dob_iso="1948-12-03",
            age=77, mrn="000389217", phone="(614) 555-1190", allergies="Codeine (nausea)")
P011 = dict(last="OSEI", first="KWAME A", sex="M", dob="09/30/1963", dob_iso="1963-09-30",
            age=62, mrn="000814463", phone="(804) 555-6605", allergies="NKDA")
P012 = dict(last="SCHNEIDER", first="RUTH E", sex="F", dob="03/17/1945", dob_iso="1945-03-17",
            age=81, mrn="000237761", phone="(614) 555-9034", allergies="NKDA")
P013 = dict(last="MORALES", first="JAVIER D", sex="M", dob="10/08/1966", dob_iso="1966-10-08",
            age=59, mrn="000905538", phone="(804) 555-7712", allergies="NSAIDs (GI upset)")
P014 = dict(last="ABERNATHY", first="LORETTA K", sex="F", dob="01/14/1960", dob_iso="1960-01-14",
            age=66, mrn="000456190", phone="(614) 555-3387", allergies="NKDA")
P015 = dict(last="RIVERA", first="SOFIA P", sex="F", dob="07/22/1993", dob_iso="1993-07-22",
            age=33, mrn="000783625", phone="(804) 555-2298", allergies="NKDA")

MANIFEST = []


def emit_lab(folder, fname, hosp, pt, meta, panels, dx):
    story = []
    for p in panels:
        story += panel_flowables(hosp, p)
    story += lab_signoff_flowables(hosp, meta)
    path = os.path.join(folder, fname)
    build_report_pdf(path, hosp, pt, meta, story)
    MANIFEST.append((pt, meta, "lab_report", path, dx))


def emit_rad(folder, fname, hosp, pt, meta, fields, impression, sig, dx):
    path = os.path.join(folder, fname)
    build_report_pdf(path, hosp, pt, meta, radiology_story(fields, impression, sig))
    MANIFEST.append((pt, meta, "imaging_report", path, dx))


def emit_note(folder, fname, hosp, pt, meta, sections, sig, dx):
    path = os.path.join(folder, fname)
    build_note_pdf(path, hosp, pt, meta, note_story(sections, sig))
    MANIFEST.append((pt, meta, "clinical_note", path, dx))


# ----------------------------------------------------------------------------
# CASE 1 — P001: Community-acquired pneumonia (Meridian)
# ----------------------------------------------------------------------------
def case_p001():
    folder = os.path.join(OUT_ROOT, "P001_pneumonia")
    os.makedirs(folder, exist_ok=True)
    hosp = MERIDIAN
    dx = "Community-acquired pneumonia, right lower lobe (ICD-10 J18.1)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0648812", encounter="CSN 88214276",
        ordering="Daniel R. Whitfield, MD (NPI 1932764801)",
        attending="Priya S. Raghavan, MD", client="MRMC-IM-114",
    )

    # --- CBC with differential
    meta = mk_meta(P001, base, accession="MR-26-0182734",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-4478210",
                   collected="06/28/2026 07:12 EDT", received="06/28/2026 07:41 EDT",
                   reported="06/28/2026 08:26 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC) WITH DIFFERENTIAL",
         "tests": [
             ("WBC", "15.8", "H", "x10E3/uL", "4.0 - 11.0"),
             ("RBC", "4.61", "", "x10E6/uL", "4.20 - 5.80"),
             ("Hemoglobin", "13.9", "", "g/dL", "13.0 - 17.0"),
             ("Hematocrit", "41.2", "", "%", "39.0 - 50.0"),
             ("MCV", "89.4", "", "fL", "80.0 - 100.0"),
             ("MCH", "30.2", "", "pg", "27.0 - 33.0"),
             ("MCHC", "33.7", "", "g/dL", "32.0 - 36.0"),
             ("RDW", "13.1", "", "%", "11.5 - 14.5"),
             ("Platelet Count", "302", "", "x10E3/uL", "150 - 400"),
             ("Neutrophils", "84.6", "H", "%", "40.0 - 70.0"),
             ("Lymphocytes", "8.2", "L", "%", "20.0 - 45.0"),
             ("Monocytes", "5.9", "", "%", "2.0 - 10.0"),
             ("Eosinophils", "0.8", "", "%", "0.0 - 5.0"),
             ("Basophils", "0.5", "", "%", "0.0 - 1.0"),
             ("Neutrophils, Absolute", "13.37", "H", "x10E3/uL", "1.80 - 7.00"),
             ("Lymphocytes, Absolute", "1.30", "", "x10E3/uL", "1.00 - 3.50"),
         ],
         "comments": [
             "Automated differential performed on Sysmex XN-3100; results verified by slide review.",
             "Leukocytosis with neutrophilic predominance; correlate clinically with infectious etiology.",
         ]},
    ]
    emit_lab(folder, "P001_CBC_with_differential.pdf", hosp, P001, meta, panels, dx)

    # --- CMP + inflammatory markers
    meta = mk_meta(P001, base, accession="MR-26-0182741",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-4478223",
                   collected="06/28/2026 07:12 EDT", received="06/28/2026 07:41 EDT",
                   reported="06/28/2026 09:03 EDT")
    panels = [
        {"name": "COMPREHENSIVE METABOLIC PANEL (CMP)",
         "tests": [
             ("Sodium", "133", "L", "mmol/L", "136 - 145"),
             ("Potassium", "3.9", "", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "98", "", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "24", "", "mmol/L", "21 - 31"),
             ("BUN", "19", "", "mg/dL", "7 - 25"),
             ("Creatinine", "1.04", "", "mg/dL", "0.70 - 1.30"),
             ("eGFR (CKD-EPI 2021)", "83", "", "mL/min/1.73m2", ">= 60"),
             ("Glucose", "118", "H", "mg/dL", "70 - 99"),
             ("Calcium", "8.9", "", "mg/dL", "8.6 - 10.3"),
             ("Protein, Total", "6.8", "", "g/dL", "6.1 - 8.1"),
             ("Albumin", "3.6", "", "g/dL", "3.6 - 5.1"),
             ("Bilirubin, Total", "0.8", "", "mg/dL", "0.2 - 1.2"),
             ("Alkaline Phosphatase", "88", "", "U/L", "36 - 130"),
             ("AST (SGOT)", "31", "", "U/L", "10 - 40"),
             ("ALT (SGPT)", "28", "", "U/L", "9 - 46"),
         ],
         "comments": ["Mild hyponatremia; consistent with acute infectious process. Recommend repeat BMP in 24 hours."]},
        {"name": "INFLAMMATORY MARKERS",
         "tests": [
             ("C-Reactive Protein (CRP)", "142.6", "H", "mg/L", "0.0 - 8.0"),
             ("Procalcitonin", "1.84", "H", "ng/mL", "< 0.10"),
             ("Lactate, Plasma", "1.6", "", "mmol/L", "0.5 - 2.0"),
         ],
         "comments": [
             "Procalcitonin 0.25 - 0.50 ng/mL: bacterial infection possible; > 0.50 ng/mL: bacterial infection likely.",
         ]},
    ]
    emit_lab(folder, "P001_CMP_inflammatory_markers.pdf", hosp, P001, meta, panels, dx)

    # --- Repeat BMP, hospital day 2 (~23 hr after initial CMP draw, same encounter)
    meta = mk_meta(P001, base, accession="MR-26-0183087",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-4479516",
                   collected="06/29/2026 06:10 EDT", received="06/29/2026 06:34 EDT",
                   reported="06/29/2026 07:48 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL (BMP) - REPEAT, HOSPITAL DAY 2",
         "tests": [
             ("Sodium", "137", "", "mmol/L", "136 - 145"),
             ("Potassium", "4.1", "", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "101", "", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "25", "", "mmol/L", "21 - 31"),
             ("BUN", "16", "", "mg/dL", "7 - 25"),
             ("Creatinine", "0.96", "", "mg/dL", "0.70 - 1.30"),
             ("eGFR (CKD-EPI 2021)", "89", "", "mL/min/1.73m2", ">= 60"),
             ("Glucose", "104", "", "mg/dL", "70 - 99"),
         ],
         "comments": ["Repeat of BMP from 06/28/2026 09:03 EDT (accession MR-26-0182741) per "
                      "attending order. Hyponatremia has resolved with isotonic fluids."]},
    ]
    emit_lab(folder, "P001_BMP_repeat_hospital_day2.pdf", hosp, P001, meta, panels, dx)

    # --- Repeat CBC, hospital day 4 / day of discharge (~4 days after admission draw)
    meta = mk_meta(P001, base, accession="MR-26-0184402",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-4481933",
                   collected="07/02/2026 06:15 EDT", received="07/02/2026 06:40 EDT",
                   reported="07/02/2026 07:22 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC) - REPEAT, DAY OF DISCHARGE",
         "tests": [
             ("WBC", "9.4", "", "x10E3/uL", "4.0 - 11.0"),
             ("RBC", "4.55", "", "x10E6/uL", "4.20 - 5.80"),
             ("Hemoglobin", "13.6", "", "g/dL", "13.0 - 17.0"),
             ("Hematocrit", "40.4", "", "%", "39.0 - 50.0"),
             ("Platelet Count", "296", "", "x10E3/uL", "150 - 400"),
             ("Neutrophils", "61.2", "", "%", "40.0 - 70.0"),
             ("Lymphocytes", "26.8", "", "%", "20.0 - 45.0"),
         ],
         "comments": ["Repeat of CBC from 06/28/2026 08:26 EDT (accession MR-26-0182734). "
                      "Leukocytosis has resolved, consistent with clinical improvement on antibiotics."]},
    ]
    emit_lab(folder, "P001_CBC_repeat_discharge_day.pdf", hosp, P001, meta, panels, dx)

    # --- Arterial blood gas
    meta = mk_meta(P001, base, accession="MR-26-0182755", doctype="BLOOD GAS REPORT",
                   specimen="Arterial Blood (Heparinized Syringe)", specimen_id="SPX-4478301",
                   g8_label="FiO2 / Device", g8_value="0.21 / Room Air",
                   collected="06/28/2026 08:05 EDT", received="06/28/2026 08:09 EDT",
                   reported="06/28/2026 08:18 EDT")
    panels = [
        {"name": "ARTERIAL BLOOD GAS (ROOM AIR)",
         "performed": "Performed at: MRMC STAT Laboratory | Radiometer ABL90",
         "tests": [
             ("pH, Arterial", "7.47", "H", "", "7.35 - 7.45"),
             ("pCO2, Arterial", "32", "L", "mmHg", "35 - 45"),
             ("pO2, Arterial", "61", "L", "mmHg", "80 - 100"),
             ("Bicarbonate (HCO3), Calc", "23", "", "mmol/L", "22 - 26"),
             ("Base Excess", "-0.8", "", "mmol/L", "-2.0 - +2.0"),
             ("O2 Saturation, Arterial", "91", "L", "%", "94 - 100"),
         ],
         "comments": [
             "Interpretation: Acute respiratory alkalosis with moderate hypoxemia on room air. "
             "A-a gradient elevated. Correlate with V/Q mismatch from airspace disease.",
             "Specimen received on ice; analyzed within 10 minutes of collection.",
         ]},
    ]
    emit_lab(folder, "P001_arterial_blood_gas.pdf", hosp, P001, meta, panels, dx)

    # --- Blood culture (microbiology)
    meta = mk_meta(P001, base, accession="MR-26-M044182", doctype="MICROBIOLOGY REPORT",
                   specimen="Blood x2 Sets (Aerobic/Anaerobic)", specimen_id="SPX-4478305",
                   collected="06/28/2026 08:20 EDT", received="06/28/2026 08:47 EDT",
                   reported="07/03/2026 08:52 EDT")
    panels = [
        {"name": "BLOOD CULTURE, ROUTINE (SET 1 OF 2 - RIGHT ANTECUBITAL)",
         "performed": "Performing Site: MRMC Microbiology | BACT/ALERT VIRTUO",
         "tests": [
             ("Gram Stain", "No organisms seen", "", "", "No organisms seen"),
             ("Culture, Preliminary (24 hr)", "No growth", "", "", "No growth"),
             ("Culture, Preliminary (48 hr)", "No growth", "", "", "No growth"),
             ("Culture, Final (5 days)", "No growth", "", "", "No growth"),
         ],
         "comments": ["FINAL REPORT: No growth after 5 days of incubation."]},
        {"name": "BLOOD CULTURE, ROUTINE (SET 2 OF 2 - LEFT ANTECUBITAL)",
         "performed": "Performing Site: MRMC Microbiology | BACT/ALERT VIRTUO",
         "tests": [
             ("Gram Stain", "No organisms seen", "", "", "No organisms seen"),
             ("Culture, Final (5 days)", "No growth", "", "", "No growth"),
         ],
         "comments": [
             "FINAL REPORT: No growth after 5 days of incubation.",
             "Streptococcus pneumoniae urinary antigen: NEGATIVE. Legionella urinary antigen: NEGATIVE.",
         ]},
    ]
    emit_lab(folder, "P001_blood_cultures_final.pdf", hosp, P001, meta, panels, dx)

    # --- Chest X-ray
    meta = mk_meta(P001, base, accession="MR-26-R071522", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="XR CHEST PA AND LATERAL",
                   collected="06/28/2026 09:14 EDT", received="06/28/2026 09:14 EDT",
                   reported="06/28/2026 10:02 EDT",
                   footer_right="PACS Study ID: 1.2.840.99.7215.20260628.4471")
    fields = [
        ("Exam", "XR CHEST PA AND LATERAL (CPT 71046)"),
        ("Indication", "58-year-old male with fever, productive cough, dyspnea, and pleuritic "
                       "right-sided chest pain x 3 days. Evaluate for pneumonia."),
        ("Technique", "Upright PA and lateral radiographs of the chest were obtained. "
                      "Two views. Comparison window/level review performed on PACS."),
        ("Comparison", "Chest radiograph dated 11/03/2024 — previously clear."),
        ("Findings", "Lungs: There is a focal airspace consolidation in the right lower lobe with "
                     "air bronchograms, best appreciated on the lateral view overlying the posterior "
                     "costophrenic sulcus. No cavitation. The left lung is clear.\n\n"
                     "Pleura: Small right pleural effusion blunting the right costophrenic angle. "
                     "No pneumothorax.\n\n"
                     "Heart/Mediastinum: Cardiac silhouette is normal in size. Mediastinal and hilar "
                     "contours are unremarkable.\n\n"
                     "Bones/Soft tissues: No acute osseous abnormality."),
    ]
    impression = [
        "Right lower lobe consolidation with air bronchograms, consistent with lobar pneumonia in the appropriate clinical setting.",
        "Small right parapneumonic pleural effusion.",
        "Recommend follow-up radiograph in 6-8 weeks to document resolution.",
    ]
    sig = ["Dictated by: Marcus J. Bell, MD — Diagnostic Radiology",
           "Electronically signed by: <b>Marcus J. Bell, MD</b>   06/28/2026 10:02 EDT",
           "Transcribed by voice recognition; read and verified by the signing radiologist."]
    emit_rad(folder, "P001_chest_xray_PA_lateral.pdf", hosp, P001, meta, fields, impression, sig, dx)

    # --- Admission H&P
    nmeta = dict(department="Internal Medicine — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="06/28/2026",
                 encounter="CSN 88214276", attending="Priya S. Raghavan, MD",
                 unit="5-West Medicine", docid="NOTE-88214276-01",
                 printed="07/02/2026 16:10 EDT",
                 footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Fever, productive cough, and shortness of breath x 3 days."),
        ("History of Present Illness",
         "Mr. Walsh is a 58-year-old male with a history of hypertension and former tobacco use "
         "(20 pack-years, quit 2015) who presents with 3 days of subjective fevers, chills, "
         "productive cough with rusty-colored sputum, and progressive dyspnea on exertion. He "
         "reports right-sided pleuritic chest pain worse with deep inspiration. No hemoptysis, "
         "no recent travel, no sick contacts, no recent hospitalization or antibiotics within 90 days. "
         "In the ED he was febrile to 38.9 C, HR 104, BP 132/78, RR 24, SpO2 89% on room air "
         "improving to 94% on 2 L nasal cannula.\n\n"
         "CURB-65 score: 1 (RR >= 30 absent, BUN 19, age 58). PSI class III. Admitted to medicine "
         "for hypoxemia requiring supplemental oxygen."),
        ("Past Medical History", ["Hypertension", "Hyperlipidemia", "Former tobacco use, quit 2015"]),
        ("Home Medications", {"table": (
            ["Medication", "Dose", "Route", "Frequency"],
            [["Lisinopril", "20 mg", "PO", "Daily"],
             ["Atorvastatin", "40 mg", "PO", "Nightly"],
             ["Aspirin", "81 mg", "PO", "Daily"]],
            [0.34, 0.16, 0.16, 0.34])}),
        ("Allergies", "No known drug allergies."),
        ("Physical Examination",
         "Vitals: T 38.9 C, HR 104, BP 132/78, RR 24, SpO2 94% on 2 L NC.\n\n"
         "General: Ill-appearing, diaphoretic, speaking in full sentences. HEENT: Oropharynx clear. "
         "Neck: Supple, no lymphadenopathy. Cardiac: Tachycardic, regular rhythm, no murmurs. "
         "Lungs: Bronchial breath sounds and coarse crackles over the right base with egophony; "
         "dullness to percussion right base. Abdomen: Soft, non-tender. Extremities: No edema. "
         "Neuro: Alert and oriented x 4."),
        ("Diagnostic Data",
         "WBC 15.8 with 84.6% neutrophils. Na 133. CRP 142.6, procalcitonin 1.84. ABG (RA): "
         "pH 7.47 / pCO2 32 / pO2 61. CXR: right lower lobe consolidation with small "
         "parapneumonic effusion. Blood cultures x2 pending. Pneumococcal and Legionella "
         "urinary antigens pending."),
        ("Assessment and Plan",
         "58-year-old male with community-acquired pneumonia (right lower lobe, CURB-65 = 1, "
         "PSI III) with hypoxemia requiring low-flow oxygen.\n\n"
         "1. CAP: Ceftriaxone 1 g IV q24h + azithromycin 500 mg IV q24h per IDSA/ATS guidelines. "
         "Blood cultures and urinary antigens pending. Incentive spirometry. Monitor effusion; "
         "small and free-flowing, no indication for thoracentesis at this time.\n"
         "2. Hypoxemia: Titrate O2 to SpO2 >= 92%. Wean as tolerated.\n"
         "3. Hyponatremia (133): Likely hypovolemic/SIADH physiology from pneumonia; isotonic "
         "fluids, repeat BMP in AM.\n"
         "4. HTN/HLD: Continue home lisinopril, atorvastatin, aspirin.\n"
         "5. VTE prophylaxis: Enoxaparin 40 mg SC daily.\n"
         "6. Code status: Full code. Disposition: anticipate 3-4 day stay."),
    ]
    sig = ["Electronically signed by: <b>Daniel R. Whitfield, MD</b> — Hospital Medicine   06/28/2026 14:22 EDT",
           "Cosigned by: <b>Priya S. Raghavan, MD</b> — Attending Physician   06/28/2026 16:05 EDT",
           "Note filed in encounter CSN 88214276. Meridian Regional Medical Center EHR."]
    emit_note(folder, "P001_admission_HP_note.pdf", hosp, P001, nmeta, sections, sig, dx)

    # --- Discharge summary
    nmeta = dict(department="Internal Medicine — Hospital Medicine",
                 note_title="DISCHARGE SUMMARY",
                 status="Signed", service_date="06/28/2026 - 07/02/2026",
                 encounter="CSN 88214276", attending="Priya S. Raghavan, MD",
                 unit="5-West Medicine", docid="NOTE-88214276-09",
                 printed="07/02/2026 16:40 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Admission / Discharge", "Admitted: 06/28/2026    Discharged: 07/02/2026    Length of stay: 4 days"),
        ("Discharge Diagnoses", [
            "Principal: Community-acquired pneumonia, right lower lobe (J18.1)",
            "Secondary: Hypoxemic respiratory insufficiency, resolved (R09.02)",
            "Secondary: Hyponatremia, resolved (E87.1)",
            "Chronic: Essential hypertension (I10); Hyperlipidemia (E78.5)"]),
        ("Hospital Course",
         "Mr. Walsh was admitted with right lower lobe community-acquired pneumonia with "
         "hypoxemia (SpO2 89% RA) and leukocytosis (WBC 15.8). He was treated with ceftriaxone "
         "1 g IV daily and azithromycin 500 mg IV daily with rapid clinical improvement: "
         "defervesced by hospital day 2, weaned to room air by hospital day 3 (SpO2 95% RA "
         "ambulating). Blood cultures x2 showed no growth at 5 days; pneumococcal and Legionella "
         "urinary antigens were negative. Repeat sodium normalized to 137 mmol/L on hospital "
         "day 2. WBC downtrended to 9.4 on day of discharge. He was transitioned to oral "
         "therapy on 07/01 and observed for 24 hours prior to discharge in stable condition."),
        ("Discharge Medications", {"table": (
            ["Medication", "Dose", "Route", "Frequency", "Notes"],
            [["Amoxicillin-clavulanate", "875/125 mg", "PO", "BID x 3 days", "New — complete 07/05/2026"],
             ["Azithromycin", "500 mg", "PO", "Daily x 2 days", "New — complete 07/04/2026"],
             ["Lisinopril", "20 mg", "PO", "Daily", "Continue"],
             ["Atorvastatin", "40 mg", "PO", "Nightly", "Continue"],
             ["Aspirin", "81 mg", "PO", "Daily", "Continue"]],
            [0.28, 0.14, 0.10, 0.18, 0.30])}),
        ("Condition at Discharge",
         "Afebrile > 48 hours, SpO2 95% on room air at rest and with ambulation, tolerating "
         "oral intake, ambulating independently. Vital signs stable."),
        ("Follow-Up and Instructions", [
            "PCP follow-up with Dr. A. Hensley within 7 days (appointment 07/08/2026, 10:20 AM).",
            "Repeat chest radiograph in 6-8 weeks to document radiographic resolution.",
            "Return precautions reviewed: recurrent fever > 38.3 C, worsening dyspnea, chest pain, hemoptysis.",
            "Smoking cessation reinforced; patient remains abstinent since 2015.",
            "Pneumococcal vaccination (PCV20) administered prior to discharge on 07/02/2026."]),
    ]
    sig = ["Electronically signed by: <b>Priya S. Raghavan, MD</b> — Attending, Hospital Medicine   07/02/2026 15:58 EDT",
           "Discharge summary completed within 48 hours of discharge per medical staff bylaws.",
           "CC: Alan Hensley, MD — Meridian Primary Care Associates (via Direct secure message)"]
    emit_note(folder, "P001_discharge_summary.pdf", hosp, P001, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 2 — P002: CKD stage 4 with anemia (Ashford)
# ----------------------------------------------------------------------------
def case_p002():
    folder = os.path.join(OUT_ROOT, "P002_ckd_stage4")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Chronic kidney disease, stage 4 (N18.4); Anemia of CKD (D63.1)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0712488", encounter="CSN 55108341",
        ordering="Elena V. Marchetti, MD (NPI 1841557203)",
        attending="Elena V. Marchetti, MD", client="AUMC-NEPH-021",
    )

    meta = mk_meta(P002, base, accession="AU-26-0448217",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-9931407",
                   collected="07/06/2026 09:05 EDT", received="07/06/2026 09:38 EDT",
                   reported="07/06/2026 12:44 EDT", fasting="Y")
    panels = [
        {"name": "COMPREHENSIVE METABOLIC PANEL (CMP)",
         "tests": [
             ("Sodium", "139", "", "mmol/L", "136 - 145"),
             ("Potassium", "5.2", "H", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "106", "", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "19", "L", "mmol/L", "21 - 31"),
             ("BUN", "48", "H", "mg/dL", "7 - 25"),
             ("Creatinine", "2.42", "H", "mg/dL", "0.50 - 1.10"),
             ("eGFR (CKD-EPI 2021)", "21", "L", "mL/min/1.73m2", ">= 60"),
             ("Glucose", "96", "", "mg/dL", "70 - 99"),
             ("Calcium", "8.7", "", "mg/dL", "8.6 - 10.3"),
             ("Protein, Total", "6.9", "", "g/dL", "6.1 - 8.1"),
             ("Albumin", "3.7", "", "g/dL", "3.6 - 5.1"),
             ("Bilirubin, Total", "0.5", "", "mg/dL", "0.2 - 1.2"),
             ("Alkaline Phosphatase", "104", "", "U/L", "34 - 104"),
             ("AST (SGOT)", "22", "", "U/L", "9 - 34"),
             ("ALT (SGPT)", "18", "", "U/L", "6 - 40"),
         ],
         "comments": ["eGFR 15-29 mL/min/1.73m2 is consistent with CKD stage G4 when chronicity criteria are met."]},
        {"name": "MINERAL AND BONE DISORDER PANEL",
         "tests": [
             ("Phosphorus", "5.1", "H", "mg/dL", "2.5 - 4.5"),
             ("Magnesium", "2.2", "", "mg/dL", "1.6 - 2.6"),
             ("Parathyroid Hormone, Intact", "218", "H", "pg/mL", "15 - 65"),
             ("Vitamin D, 25-Hydroxy", "21.4", "L", "ng/mL", "30.0 - 100.0"),
         ],
         "comments": [
             "Intact PTH by chemiluminescent immunoassay (Roche cobas e801).",
             "Findings consistent with secondary hyperparathyroidism of chronic kidney disease.",
         ]},
    ]
    emit_lab(folder, "P002_CMP_bone_mineral_panel.pdf", hosp, P002, meta, panels, dx)

    meta = mk_meta(P002, base, accession="AU-26-0448220",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-9931412",
                   collected="07/06/2026 09:05 EDT", received="07/06/2026 09:38 EDT",
                   reported="07/06/2026 10:52 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "6.8", "", "x10E3/uL", "4.0 - 11.0"),
             ("RBC", "3.24", "L", "x10E6/uL", "3.80 - 5.20"),
             ("Hemoglobin", "9.4", "L", "g/dL", "11.7 - 15.5"),
             ("Hematocrit", "28.6", "L", "%", "35.0 - 45.0"),
             ("MCV", "88.3", "", "fL", "80.0 - 100.0"),
             ("MCH", "29.0", "", "pg", "27.0 - 33.0"),
             ("MCHC", "32.9", "", "g/dL", "32.0 - 36.0"),
             ("RDW", "14.1", "", "%", "11.5 - 14.5"),
             ("Platelet Count", "214", "", "x10E3/uL", "150 - 400"),
             ("Reticulocyte Count", "1.4", "", "%", "0.5 - 2.5"),
         ],
         "comments": ["Normocytic, normochromic anemia with inappropriately normal reticulocyte "
                      "response; pattern consistent with anemia of chronic kidney disease."]},
    ]
    emit_lab(folder, "P002_CBC_reticulocyte.pdf", hosp, P002, meta, panels, dx)

    meta = mk_meta(P002, base, accession="AU-26-0448231",
                   specimen="Serum (SST) / Random Urine", specimen_id="SPX-9931418",
                   collected="07/06/2026 09:05 EDT", received="07/06/2026 09:38 EDT",
                   reported="07/06/2026 13:21 EDT")
    panels = [
        {"name": "ANEMIA / IRON STUDIES",
         "tests": [
             ("Iron, Total", "52", "", "ug/dL", "37 - 145"),
             ("Total Iron Binding Capacity", "274", "", "ug/dL", "250 - 450"),
             ("Transferrin Saturation", "19", "", "%", "15 - 50"),
             ("Ferritin", "148", "", "ng/mL", "16 - 232"),
             ("Vitamin B12", "412", "", "pg/mL", "232 - 1245"),
             ("Folate, Serum", "12.8", "", "ng/mL", "> 4.8"),
         ],
         "comments": ["Iron stores adequate (ferritin > 100 ng/mL and TSAT > 15%); B12/folate replete. "
                      "Anemia work-up supports renal etiology (relative erythropoietin deficiency)."]},
        {"name": "URINE CHEMISTRY",
         "tests": [
             ("Albumin, Urine", "62.3", "", "mg/dL", "Not established"),
             ("Creatinine, Urine", "70.0", "", "mg/dL", "Not established"),
             ("Albumin/Creatinine Ratio", "890", "H", "mg/g creat", "< 30"),
         ],
         "comments": ["Severely increased albuminuria (KDIGO category A3)."]},
    ]
    emit_lab(folder, "P002_iron_studies_urine_ACR.pdf", hosp, P002, meta, panels, dx)

    # Renal ultrasound
    meta = mk_meta(P002, base, accession="AU-26-R033910", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   g8_label="Exam", g8_value="US RENAL COMPLETE",
                   specimen="", collected="07/06/2026 10:15 EDT",
                   received="07/06/2026 10:15 EDT", reported="07/06/2026 11:40 EDT",
                   footer_right="PACS Study ID: 1.2.840.99.4410.20260706.2213")
    fields = [
        ("Exam", "US RENAL (KIDNEYS AND BLADDER), COMPLETE (CPT 76770)"),
        ("Indication", "67-year-old female with CKD stage 4 (eGFR 21), evaluate renal size and "
                       "exclude obstruction."),
        ("Technique", "Grayscale and color Doppler sonographic evaluation of both kidneys and the "
                      "urinary bladder."),
        ("Comparison", "None available."),
        ("Findings", "Right kidney: 8.9 cm in length with diffusely increased cortical "
                     "echogenicity and cortical thinning (0.9 cm). No hydronephrosis, calculus, "
                     "or mass.\n\n"
                     "Left kidney: 9.2 cm in length with similar increased cortical echogenicity "
                     "and thinning. No hydronephrosis or focal lesion.\n\n"
                     "Bladder: Normal wall thickness. Post-void residual 18 mL.\n\n"
                     "Color Doppler: Symmetric renal perfusion; main renal arteries and veins patent."),
    ]
    impression = [
        "Bilaterally small, echogenic kidneys with cortical thinning, consistent with chronic medical renal disease.",
        "No hydronephrosis, nephrolithiasis, or renal mass. No obstructive uropathy.",
    ]
    sig = ["Dictated by: Nina P. Vasquez, MD — Diagnostic Radiology",
           "Electronically signed by: <b>Nina P. Vasquez, MD</b>   07/06/2026 11:40 EDT"]
    emit_rad(folder, "P002_renal_ultrasound.pdf", hosp, P002, meta, fields, impression, sig, dx)

    # Nephrology consult note
    nmeta = dict(department="Division of Nephrology — Ambulatory Clinic",
                 note_title="NEPHROLOGY CLINIC NOTE",
                 status="Signed", service_date="07/06/2026",
                 encounter="CSN 55108341", attending="Elena V. Marchetti, MD",
                 unit="Nephrology Clinic, Suite 320", docid="NOTE-55108341-02",
                 printed="07/06/2026 17:05 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Follow-up of chronic kidney disease; fatigue and decreased exercise tolerance."),
        ("History of Present Illness",
         "Ms. Okonkwo is a 67-year-old female with CKD stage 4 secondary to longstanding "
         "hypertension and type 2 diabetes mellitus, followed in nephrology clinic since 2023. "
         "eGFR has declined from 28 (01/2026) to 21 mL/min/1.73m2 today. She reports progressive "
         "fatigue, dyspnea on exertion after one flight of stairs, and reduced exercise tolerance "
         "over 3 months. No chest pain, orthopnea, melena, or menorrhagia (postmenopausal). "
         "Adherent to low-potassium, low-phosphorus renal diet."),
        ("Past Medical History", ["Chronic kidney disease, stage 4 (baseline Cr 2.2 - 2.4)",
                                  "Hypertension x 22 years", "Type 2 diabetes mellitus (A1c 7.1%, 04/2026)",
                                  "Secondary hyperparathyroidism"]),
        ("Current Medications", {"table": (
            ["Medication", "Dose", "Route", "Frequency"],
            [["Losartan", "50 mg", "PO", "Daily"],
             ["Amlodipine", "10 mg", "PO", "Daily"],
             ["Furosemide", "40 mg", "PO", "Daily"],
             ["Sevelamer carbonate", "800 mg", "PO", "TID with meals"],
             ["Insulin glargine", "18 units", "SC", "Nightly"],
             ["Cholecalciferol", "2000 IU", "PO", "Daily"]],
            [0.34, 0.16, 0.16, 0.34])}),
        ("Physical Examination",
         "Vitals: BP 138/82, HR 78, RR 16, SpO2 98% RA, Weight 71.4 kg (stable).\n\n"
         "General: Pale conjunctivae. Cardiac: Regular rate and rhythm, no rub. Lungs: Clear "
         "bilaterally. Abdomen: Soft, non-tender. Extremities: Trace bilateral pitting edema. "
         "No asterixis."),
        ("Results Reviewed",
         "Today's labs: Cr 2.42 (eGFR 21), K 5.2, CO2 19, phosphorus 5.1, iPTH 218, 25-OH "
         "vitamin D 21.4, Hgb 9.4 (from 10.6 in 01/2026), ferritin 148, TSAT 19%, B12 and "
         "folate replete, UACR 890 mg/g. Renal ultrasound today: bilaterally small echogenic "
         "kidneys, no obstruction."),
        ("Assessment and Plan",
         "67-year-old female with CKD stage G4/A3 (hypertensive and diabetic nephrosclerosis) "
         "with progressive anemia of CKD, secondary hyperparathyroidism, and metabolic acidosis.\n\n"
         "1. Anemia of CKD (Hgb 9.4): Iron replete; B12/folate normal; no evidence of GI loss. "
         "Meets criteria for erythropoiesis-stimulating agent. Initiate epoetin alfa 4,000 units "
         "SC weekly, target Hgb 10-11 g/dL. PRIOR AUTHORIZATION submitted to payer this visit "
         "with supporting labs (Hgb < 10 g/dL, ferritin > 100 ng/mL, TSAT > 15%).\n"
         "2. Secondary hyperparathyroidism (iPTH 218, phos 5.1): Continue sevelamer with meals; "
         "start ergocalciferol 50,000 IU weekly x 8 weeks for vitamin D insufficiency; recheck "
         "iPTH/phosphorus in 8 weeks.\n"
         "3. Metabolic acidosis (CO2 19): Start sodium bicarbonate 650 mg PO BID; target CO2 >= 22.\n"
         "4. Hyperkalemia (K 5.2): Dietary counseling reinforced today; recheck BMP in 2 weeks.\n"
         "5. CKD progression: Continue losartan; BP goal < 130/80. Modality education scheduled "
         "(hemodialysis vs peritoneal dialysis); vein preservation counseling given — no venipuncture "
         "or BP in left arm. Transplant evaluation referral placed.\n"
         "6. Return to clinic in 6 weeks with BMP, CBC, iPTH, phosphorus."),
    ]
    sig = ["Electronically signed by: <b>Elena V. Marchetti, MD</b> — Nephrology   07/06/2026 16:48 EDT",
           "CC: Primary Care — Denise Carver, MD (via Direct secure message)"]
    emit_note(folder, "P002_nephrology_clinic_note.pdf", hosp, P002, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 3 — P003: NSTEMI (Ashford)
# ----------------------------------------------------------------------------
def case_p003():
    folder = os.path.join(OUT_ROOT, "P003_nstemi")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Non-ST-elevation myocardial infarction (I21.4)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0688204", encounter="CSN 55097122",
        ordering="Sarah J. Lindqvist, MD (NPI 1720448816)",
        attending="Thomas K. Adeyemi, MD, FACC", client="AUMC-ED-003",
    )

    meta = mk_meta(P003, base, accession="AU-26-0431866",
                   specimen="Plasma (Lithium Heparin, Green)", specimen_id="SPX-9902241",
                   collected="06/20/2026 21:34 EDT", received="06/20/2026 21:52 EDT",
                   reported="06/21/2026 04:20 EDT")
    panels = [
        {"name": "CARDIAC BIOMARKERS — SERIAL",
         "performed": "Performing Site: AUMC STAT Laboratory | Abbott Alinity i",
         "tests": [
             ("Troponin I, High Sensitivity (0 hr)", "412", "H", "ng/L", "<= 34 (M)"),
             ("Troponin I, High Sensitivity (3 hr)", "1,862", "H", "ng/L", "<= 34 (M)"),
             ("Troponin I, High Sensitivity (6 hr)", "3,214", "H", "ng/L", "<= 34 (M)"),
         ],
         "comments": [
             "Serial collections: 06/20/2026 21:34, 06/21/2026 00:35, 06/21/2026 03:38 EDT.",
             "Rising troponin pattern with delta > 20% is consistent with acute myocardial injury. "
             "Correlate with ECG and clinical presentation.",
             "CRITICAL RESULT: 3-hr value called to S. Lindqvist, MD by J. Reyes, MLS on "
             "06/21/2026 00:58 EDT; read-back confirmed.",
         ]},
    ]
    emit_lab(folder, "P003_serial_troponin.pdf", hosp, P003, meta, panels, dx)

    meta = mk_meta(P003, base, accession="AU-26-0431870",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-9902248",
                   collected="06/21/2026 06:10 EDT", received="06/21/2026 06:31 EDT",
                   reported="06/21/2026 08:05 EDT", fasting="Y")
    panels = [
        {"name": "BASIC METABOLIC PANEL (BMP)",
         "tests": [
             ("Sodium", "140", "", "mmol/L", "136 - 145"),
             ("Potassium", "4.2", "", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "102", "", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "25", "", "mmol/L", "21 - 31"),
             ("BUN", "17", "", "mg/dL", "7 - 25"),
             ("Creatinine", "1.02", "", "mg/dL", "0.70 - 1.30"),
             ("eGFR (CKD-EPI 2021)", "80", "", "mL/min/1.73m2", ">= 60"),
             ("Glucose", "132", "H", "mg/dL", "70 - 99"),
             ("Calcium", "9.2", "", "mg/dL", "8.6 - 10.3"),
         ],
         "comments": []},
        {"name": "LIPID PANEL, FASTING",
         "tests": [
             ("Cholesterol, Total", "234", "H", "mg/dL", "< 200"),
             ("Triglycerides", "190", "H", "mg/dL", "< 150"),
             ("HDL Cholesterol", "38", "L", "mg/dL", "> 39"),
             ("LDL Cholesterol, Calculated", "158", "H", "mg/dL", "< 100"),
             ("Non-HDL Cholesterol", "196", "H", "mg/dL", "< 130"),
             ("Cholesterol/HDL Ratio", "6.2", "H", "", "< 5.0"),
         ],
         "comments": ["LDL calculated by Martin-Hopkins equation. In patients with established "
                      "ASCVD, guideline-directed LDL-C goal is < 70 mg/dL."]},
        {"name": "HEMOGLOBIN A1c",
         "tests": [("Hemoglobin A1c", "6.1", "H", "%", "4.0 - 5.6")],
         "comments": ["5.7 - 6.4%: consistent with prediabetes (ADA criteria)."]},
    ]
    emit_lab(folder, "P003_BMP_lipids_A1c.pdf", hosp, P003, meta, panels, dx)

    # ECG report
    meta = mk_meta(P003, base, accession="AU-26-E019441", doctype="ELECTROCARDIOGRAM REPORT",
                   department="Heart and Vascular Institute — Cardiology",
                   g8_label="Exam", g8_value="ECG 12-LEAD (CPT 93000)",
                   specimen="", collected="06/20/2026 21:26 EDT",
                   received="06/20/2026 21:26 EDT", reported="06/20/2026 21:58 EDT",
                   footer_right="MUSE Order 20260620-8841")
    fields = [
        ("Exam", "12-LEAD ELECTROCARDIOGRAM, RESTING"),
        ("Indication", "61-year-old male with 2 hours of substernal chest pressure radiating to "
                       "the left arm, diaphoresis. Rule out acute coronary syndrome."),
        ("Measurements", "Ventricular rate 92 bpm. PR 168 ms. QRS 88 ms. QT/QTc 372/438 ms. "
                         "Axis: P 54, QRS -12, T 96."),
        ("Findings", "Normal sinus rhythm at 92 bpm. Horizontal ST-segment depression of 1.5 mm "
                     "in leads V4-V6, I, and aVL with associated T-wave inversion. No ST-segment "
                     "elevation. No pathologic Q waves. Compared with tracing of 09/12/2025, "
                     "ST-T changes in the lateral leads are new."),
    ]
    impression = [
        "Normal sinus rhythm.",
        "New lateral ST-segment depression and T-wave inversion, concerning for myocardial ischemia.",
        "Findings communicated to the ED physician at time of interpretation.",
    ]
    sig = ["Interpreted and electronically signed by: <b>Thomas K. Adeyemi, MD, FACC</b>   06/20/2026 21:58 EDT",
           "Confirmed against prior ECG dated 09/12/2025."]
    emit_rad(folder, "P003_ECG_12_lead.pdf", hosp, P003, meta, fields, impression, sig, dx)

    # Echo
    meta = mk_meta(P003, base, accession="AU-26-C007218", doctype="ECHOCARDIOGRAM REPORT",
                   department="Heart and Vascular Institute — Echocardiography Laboratory",
                   g8_label="Exam", g8_value="TTE COMPLETE W/ DOPPLER (CPT 93306)",
                   specimen="", collected="06/21/2026 10:30 EDT",
                   received="06/21/2026 10:30 EDT", reported="06/21/2026 13:15 EDT",
                   footer_right="IAC-Accredited Echocardiography Laboratory")
    fields = [
        ("Exam", "TRANSTHORACIC ECHOCARDIOGRAM, COMPLETE, WITH SPECTRAL AND COLOR DOPPLER"),
        ("Indication", "NSTEMI. Assess left ventricular function and regional wall motion."),
        ("Technique", "2D, M-mode, spectral and color Doppler imaging from standard windows. "
                      "Image quality: adequate."),
        ("Findings", "Left ventricle: Mildly reduced systolic function, estimated LVEF 45% "
                     "(biplane Simpson). Hypokinesis of the basal-to-mid inferolateral and "
                     "lateral walls. No LV thrombus. LV wall thickness normal.\n\n"
                     "Right ventricle: Normal size and systolic function (TAPSE 21 mm).\n\n"
                     "Atria: Mild left atrial enlargement (LAVI 36 mL/m2).\n\n"
                     "Valves: Mild mitral regurgitation. Aortic valve trileaflet, no stenosis. "
                     "No significant tricuspid or pulmonic disease. Estimated RVSP 32 mmHg.\n\n"
                     "Pericardium: No effusion."),
    ]
    impression = [
        "Mildly reduced LV systolic function, LVEF 45%.",
        "Regional wall motion abnormality of the inferolateral and lateral walls, consistent with ischemia/infarction in the circumflex territory.",
        "Mild mitral regurgitation.",
    ]
    sig = ["Sonographer: K. Brennan, RDCS",
           "Interpreted and electronically signed by: <b>Nina P. Vasquez, MD</b> — Level III Echocardiography   06/21/2026 13:15 EDT"]
    emit_rad(folder, "P003_echocardiogram_TTE.pdf", hosp, P003, meta, fields, impression, sig, dx)

    # Cath report
    meta = mk_meta(P003, base, accession="AU-26-C007233", doctype="CARDIAC CATHETERIZATION REPORT",
                   department="Heart and Vascular Institute — Cardiac Catheterization Laboratory",
                   g8_label="Procedure", g8_value="LHC / CORONARY ANGIO / PCI",
                   specimen="", collected="06/22/2026 08:05 EDT",
                   received="06/22/2026 08:05 EDT", reported="06/22/2026 11:20 EDT",
                   footer_right="Cath Lab Case 2026-0619")
    fields = [
        ("Procedure", "Left heart catheterization, selective coronary angiography, percutaneous "
                      "coronary intervention (PCI) of the left circumflex artery with drug-eluting stent."),
        ("Indication", "NSTEMI with rising troponin and new lateral wall motion abnormality."),
        ("Access / Technique", "Right radial artery, 6 Fr sheath. Heparin per ACT protocol "
                               "(peak ACT 287 s). Contrast: iohexol 68 mL. Fluoroscopy time 9.4 min."),
        ("Angiographic Findings",
         "Left main: No angiographically significant disease.\n\n"
         "LAD: 30% mid-vessel stenosis, non-obstructive.\n\n"
         "Left circumflex: 90% discrete stenosis of the mid-LCx (culprit lesion) with TIMI 2 "
         "flow.\n\n"
         "RCA: Dominant vessel, 20% proximal irregularity, non-obstructive."),
        ("Intervention",
         "Mid-LCx lesion pre-dilated with 2.5 x 15 mm balloon, then stented with a "
         "3.0 x 18 mm everolimus-eluting stent, post-dilated to 3.25 mm. Final result: 0% "
         "residual stenosis, TIMI 3 flow, no dissection, no perforation. Radial band applied; "
         "no access-site complication."),
    ]
    impression = [
        "Culprit 90% mid-left circumflex stenosis, successfully treated with one drug-eluting stent; final TIMI 3 flow.",
        "Non-obstructive disease of the LAD and RCA; medical management.",
        "Recommend dual antiplatelet therapy (aspirin + ticagrelor) for a minimum of 12 months.",
    ]
    sig = ["Operator: <b>Thomas K. Adeyemi, MD, FACC</b> — Interventional Cardiology",
           "Electronically signed: 06/22/2026 11:20 EDT",
           "Fellow: R. Osei, MD. Cath lab nursing record filed separately."]
    emit_rad(folder, "P003_cardiac_cath_PCI_report.pdf", hosp, P003, meta, fields, impression, sig, dx)

    # --- Post-PCI CBC, ~6 hr after sheath pull (access-site bleeding check)
    meta = mk_meta(P003, base, accession="AU-26-0432204",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-9903390",
                   collected="06/22/2026 17:45 EDT", received="06/22/2026 18:02 EDT",
                   reported="06/22/2026 18:40 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC) - POST-PROCEDURE, 6 HR",
         "tests": [
             ("WBC", "8.6", "", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "14.1", "", "g/dL", "13.5 - 17.5 (M)"),
             ("Hematocrit", "41.8", "", "%", "41.0 - 50.0 (M)"),
             ("Platelet Count", "241", "", "x10E3/uL", "150 - 400"),
         ],
         "comments": ["Post-PCI surveillance CBC per interventional cardiology protocol; stable "
                      "from pre-procedure baseline (Hgb 14.3 g/dL). No evidence of access-site "
                      "or retroperitoneal bleeding."]},
    ]
    emit_lab(folder, "P003_CBC_post_PCI_6hr.pdf", hosp, P003, meta, panels, dx)

    # Discharge summary
    nmeta = dict(department="Heart and Vascular Institute — Cardiology",
                 note_title="DISCHARGE SUMMARY",
                 status="Signed", service_date="06/20/2026 - 06/24/2026",
                 encounter="CSN 55097122", attending="Thomas K. Adeyemi, MD, FACC",
                 unit="Cardiac Telemetry, 7-North", docid="NOTE-55097122-11",
                 printed="06/24/2026 15:12 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Admission / Discharge", "Admitted: 06/20/2026    Discharged: 06/24/2026    Length of stay: 4 days"),
        ("Discharge Diagnoses", [
            "Principal: Non-ST-elevation myocardial infarction (I21.4)",
            "Secondary: Coronary artery disease of native artery, s/p PCI with DES to mid-LCx (I25.10, Z95.5)",
            "Secondary: Mixed hyperlipidemia (E78.2); Prediabetes (R73.03)"]),
        ("Hospital Course",
         "Mr. Delgado presented with 2 hours of substernal chest pressure. Initial hs-troponin I "
         "412 ng/L rising to 3,214 ng/L with new lateral ST depression on ECG, consistent with "
         "NSTEMI. He was treated with aspirin 324 mg, ticagrelor 180 mg load, and a heparin "
         "infusion. Echocardiogram showed LVEF 45% with inferolateral hypokinesis. Coronary "
         "angiography on 06/22 revealed a culprit 90% mid-LCx stenosis treated with a single "
         "drug-eluting stent (TIMI 3 final flow). Post-PCI course was uncomplicated; telemetry "
         "showed no arrhythmia; radial access site remained intact. He was ambulating without "
         "angina at discharge."),
        ("Discharge Medications", {"table": (
            ["Medication", "Dose", "Route", "Frequency", "Notes"],
            [["Aspirin", "81 mg", "PO", "Daily", "Indefinite"],
             ["Ticagrelor", "90 mg", "PO", "BID", "Minimum 12 months — do not stop without cardiology approval"],
             ["Atorvastatin", "80 mg", "PO", "Nightly", "High-intensity statin"],
             ["Metoprolol succinate", "50 mg", "PO", "Daily", "New"],
             ["Lisinopril", "5 mg", "PO", "Daily", "New — titrate at follow-up"],
             ["Nitroglycerin SL", "0.4 mg", "SL", "PRN chest pain", "Instructions provided"]],
            [0.24, 0.12, 0.08, 0.14, 0.42])}),
        ("Follow-Up and Instructions", [
            "Cardiology clinic (Dr. Adeyemi) in 2 weeks — appointment 07/08/2026, 9:00 AM.",
            "Cardiac rehabilitation referral placed (Phase II); enrollment call expected within 7 days.",
            "Repeat lipid panel in 6 weeks to assess response to high-intensity statin (goal LDL-C < 70 mg/dL).",
            "Diabetes prevention counseling for prediabetes (A1c 6.1%); repeat A1c in 3 months.",
            "Return precautions: recurrent chest pain unrelieved by rest/nitroglycerin, dyspnea, syncope, bleeding."]),
        ("Condition at Discharge",
         "Hemodynamically stable, chest-pain free > 48 hours, ambulating independently. "
         "Right radial access site clean, dry, intact."),
    ]
    sig = ["Electronically signed by: <b>Thomas K. Adeyemi, MD, FACC</b> — Attending Cardiologist   06/24/2026 14:47 EDT",
           "CC: Primary Care — Marcus Doyle, MD (via Direct secure message)"]
    emit_note(folder, "P003_discharge_summary.pdf", hosp, P003, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 4 — P004: Uncontrolled T2DM (Meridian)
# ----------------------------------------------------------------------------
def case_p004():
    folder = os.path.join(OUT_ROOT, "P004_diabetes_uncontrolled")
    os.makedirs(folder, exist_ok=True)
    hosp = MERIDIAN
    dx = "Type 2 diabetes mellitus with hyperglycemia, uncontrolled (E11.65)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0701147", encounter="CSN 88240519",
        ordering="Victor H. Salazar, MD (NPI 1659812440)",
        attending="Victor H. Salazar, MD", client="MRMC-ENDO-042",
    )

    meta = mk_meta(P004, base, accession="MR-26-0191408",
                   specimen="Serum (SST) / EDTA WB / Random Urine", specimen_id="SPX-4492176",
                   collected="07/08/2026 08:22 EDT", received="07/08/2026 08:51 EDT",
                   reported="07/08/2026 12:37 EDT", fasting="Y")
    panels = [
        {"name": "HEMOGLOBIN A1c",
         "tests": [
             ("Hemoglobin A1c", "10.4", "H", "%", "4.0 - 5.6"),
             ("Estimated Average Glucose", "252", "H", "mg/dL", "Not established"),
         ],
         "comments": ["NGSP-certified HPLC method (Bio-Rad D-100). A1c >= 6.5% is consistent with "
                      "diabetes mellitus (ADA criteria). ADA general treatment goal: < 7.0%."]},
        {"name": "COMPREHENSIVE METABOLIC PANEL (CMP)",
         "tests": [
             ("Sodium", "137", "", "mmol/L", "136 - 145"),
             ("Potassium", "4.4", "", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "100", "", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "25", "", "mmol/L", "21 - 31"),
             ("BUN", "15", "", "mg/dL", "7 - 25"),
             ("Creatinine", "0.84", "", "mg/dL", "0.50 - 1.10"),
             ("eGFR (CKD-EPI 2021)", "82", "", "mL/min/1.73m2", ">= 60"),
             ("Glucose, Fasting", "262", "H", "mg/dL", "70 - 99"),
             ("Calcium", "9.4", "", "mg/dL", "8.6 - 10.3"),
             ("Albumin", "4.2", "", "g/dL", "3.6 - 5.1"),
             ("AST (SGOT)", "34", "", "U/L", "9 - 34"),
             ("ALT (SGPT)", "44", "H", "U/L", "6 - 40"),
         ],
         "comments": ["Mild transaminase elevation; consider hepatic steatosis in the setting of "
                      "metabolic syndrome. Recommend repeat LFTs in 3 months."]},
        {"name": "LIPID PANEL, FASTING",
         "tests": [
             ("Cholesterol, Total", "212", "H", "mg/dL", "< 200"),
             ("Triglycerides", "246", "H", "mg/dL", "< 150"),
             ("HDL Cholesterol", "42", "", "mg/dL", "> 50"),
             ("LDL Cholesterol, Calculated", "128", "H", "mg/dL", "< 100"),
             ("Non-HDL Cholesterol", "170", "H", "mg/dL", "< 130"),
         ], "comments": []},
        {"name": "THYROID / URINE STUDIES",
         "tests": [
             ("TSH", "2.14", "", "mIU/L", "0.45 - 4.50"),
             ("Albumin/Creatinine Ratio, Urine", "74", "H", "mg/g creat", "< 30"),
         ],
         "comments": ["Moderately increased albuminuria (KDIGO A2); repeat in 3-6 months to confirm."]},
    ]
    emit_lab(folder, "P004_A1c_CMP_lipids_TSH_uACR.pdf", hosp, P004, meta, panels, dx)

    nmeta = dict(department="Division of Endocrinology — Ambulatory Clinic",
                 note_title="ENDOCRINOLOGY CLINIC NOTE",
                 status="Signed", service_date="07/08/2026",
                 encounter="CSN 88240519", attending="Victor H. Salazar, MD",
                 unit="Endocrinology Clinic, Suite 210", docid="NOTE-88240519-01",
                 printed="07/08/2026 17:20 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Poorly controlled type 2 diabetes; referred by primary care for medication intensification."),
        ("History of Present Illness",
         "Ms. Tran is a 52-year-old female with a 9-year history of type 2 diabetes mellitus "
         "referred for worsening glycemic control. A1c has risen from 8.6% (10/2025) to 10.4% "
         "today despite maximally tolerated metformin and the addition of glipizide in 2024. "
         "She reports polyuria, polydipsia, and 8-lb unintentional weight loss over 3 months, "
         "without polyphagia, blurred vision, paresthesias, or hypoglycemic episodes. Home "
         "fasting glucose runs 210-260 mg/dL. BMI today 34.2 kg/m2. Diet reviewed with prior "
         "nutrition counseling; adherence to medications confirmed by pharmacy fill history."),
        ("Past Medical History", ["Type 2 diabetes mellitus, diagnosed 2017",
                                  "Obesity (BMI 34.2)", "Mixed dyslipidemia",
                                  "Moderately increased albuminuria (new, confirmed pending)"]),
        ("Current Medications", {"table": (
            ["Medication", "Dose", "Route", "Frequency"],
            [["Metformin ER", "1000 mg", "PO", "BID"],
             ["Glipizide XL", "10 mg", "PO", "Daily"],
             ["Rosuvastatin", "10 mg", "PO", "Nightly"]],
            [0.34, 0.16, 0.16, 0.34])}),
        ("Physical Examination",
         "Vitals: BP 128/79, HR 82, Weight 92.6 kg, BMI 34.2.\n\n"
         "General: Well-appearing, obese habitus. Neck: No thyromegaly. Cardiac: RRR. Lungs: "
         "Clear. Feet: Intact protective sensation to 10-g monofilament bilaterally; pulses 2+; "
         "no ulceration. Skin: Mild acanthosis nigricans, posterior neck."),
        ("Results Reviewed",
         "A1c 10.4% (eAG 252). Fasting glucose 262. eGFR 82, UACR 74 mg/g (A2). ALT 44. "
         "Lipids: LDL 128, TG 246, HDL 42. TSH normal."),
        ("Assessment and Plan",
         "52-year-old female with uncontrolled type 2 diabetes (A1c 10.4%) on dual oral therapy, "
         "with obesity and new moderately increased albuminuria.\n\n"
         "1. T2DM, uncontrolled: Initiate semaglutide 0.25 mg SC weekly, titrating to 1.0 mg per "
         "label. Rationale: A1c > 9% on two oral agents, BMI 34.2, weight-loss benefit, and "
         "albuminuria. PRIOR AUTHORIZATION submitted with this note and today's laboratory "
         "report (documented failure of metformin + sulfonylurea, A1c 10.4%). Continue "
         "metformin ER 1000 mg BID; discontinue glipizide once semaglutide reaches 0.5 mg "
         "weekly to reduce hypoglycemia risk.\n"
         "2. Albuminuria (UACR 74): Repeat UACR x 2 over 3-6 months; if persistent, initiate "
         "ACE inhibitor. Annual dilated eye exam ordered; last documented 2024.\n"
         "3. Dyslipidemia: Intensify rosuvastatin to 20 mg nightly (diabetes + age > 40, "
         "10-yr ASCVD risk 14.8%).\n"
         "4. Elevated ALT: Likely MASLD; hepatic function panel and FIB-4 at next visit.\n"
         "5. Education: Diabetes self-management education referral; glucometer download "
         "reviewed; hypoglycemia precautions discussed.\n"
         "6. Return to clinic in 12 weeks with repeat A1c, BMP, and UACR."),
    ]
    sig = ["Electronically signed by: <b>Victor H. Salazar, MD</b> — Endocrinology   07/08/2026 16:55 EDT",
           "CC: Referring PCP — Alan Hensley, MD, Meridian Primary Care Associates"]
    emit_note(folder, "P004_endocrinology_clinic_note.pdf", hosp, P004, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 5 — P005: Acute decompensated heart failure (Ashford)
# ----------------------------------------------------------------------------
def case_p005():
    folder = os.path.join(OUT_ROOT, "P005_chf_exacerbation")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Acute on chronic systolic (HFrEF) heart failure (I50.23)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0709917", encounter="CSN 55121808",
        ordering="Sarah J. Lindqvist, MD (NPI 1720448816)",
        attending="Thomas K. Adeyemi, MD, FACC", client="AUMC-ED-003",
    )

    meta = mk_meta(P005, base, accession="AU-26-0450112",
                   specimen="Plasma (EDTA, Lavender) / Serum (SST)", specimen_id="SPX-9938864",
                   collected="07/03/2026 14:42 EDT", received="07/03/2026 15:05 EDT",
                   reported="07/03/2026 16:33 EDT")
    panels = [
        {"name": "CARDIAC / HEART FAILURE MARKERS",
         "tests": [
             ("B-Type Natriuretic Peptide (BNP)", "1,480", "H", "pg/mL", "<= 100"),
             ("Troponin I, High Sensitivity", "28", "", "ng/L", "<= 34 (M)"),
         ],
         "comments": ["BNP > 400 pg/mL is consistent with heart failure in the appropriate "
                      "clinical context. Repeat troponin at 3 hours showed no significant delta (31 ng/L)."]},
        {"name": "COMPREHENSIVE METABOLIC PANEL (CMP)",
         "tests": [
             ("Sodium", "132", "L", "mmol/L", "136 - 145"),
             ("Potassium", "4.4", "", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "96", "L", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "27", "", "mmol/L", "21 - 31"),
             ("BUN", "34", "H", "mg/dL", "7 - 25"),
             ("Creatinine", "1.42", "H", "mg/dL", "0.70 - 1.30"),
             ("eGFR (CKD-EPI 2021)", "52", "L", "mL/min/1.73m2", ">= 60"),
             ("Glucose", "108", "H", "mg/dL", "70 - 99"),
             ("Calcium", "9.0", "", "mg/dL", "8.6 - 10.3"),
             ("Albumin", "3.8", "", "g/dL", "3.6 - 5.1"),
             ("Bilirubin, Total", "1.1", "", "mg/dL", "0.2 - 1.2"),
             ("AST (SGOT)", "38", "H", "U/L", "9 - 34"),
             ("ALT (SGPT)", "36", "", "U/L", "6 - 40"),
         ],
         "comments": ["Dilutional hyponatremia and cardiorenal pattern (BUN/Cr ratio 24) in the "
                      "setting of volume overload. Mild transaminase elevation may reflect hepatic congestion."]},
    ]
    emit_lab(folder, "P005_BNP_CMP.pdf", hosp, P005, meta, panels, dx)

    meta = mk_meta(P005, base, accession="AU-26-0450118",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-9938870",
                   collected="07/03/2026 14:42 EDT", received="07/03/2026 15:05 EDT",
                   reported="07/03/2026 15:58 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "7.9", "", "x10E3/uL", "4.0 - 11.0"),
             ("RBC", "4.48", "", "x10E6/uL", "4.20 - 5.80"),
             ("Hemoglobin", "13.4", "", "g/dL", "13.0 - 17.0"),
             ("Hematocrit", "40.1", "", "%", "39.0 - 50.0"),
             ("MCV", "89.5", "", "fL", "80.0 - 100.0"),
             ("RDW", "13.8", "", "%", "11.5 - 14.5"),
             ("Platelet Count", "188", "", "x10E3/uL", "150 - 400"),
         ],
         "comments": ["No leukocytosis or anemia; infection less likely as precipitant."]},
        {"name": "COAGULATION / THYROID",
         "tests": [
             ("Prothrombin Time (PT)", "13.1", "", "sec", "11.6 - 14.5"),
             ("INR", "1.0", "", "", "0.9 - 1.2"),
             ("TSH", "1.86", "", "mIU/L", "0.45 - 4.50"),
         ],
         "comments": ["Thyroid function normal; thyrotoxicosis excluded as heart failure precipitant."]},
    ]
    emit_lab(folder, "P005_CBC_coags_TSH.pdf", hosp, P005, meta, panels, dx)

    # --- Repeat BMP, hospital day 3 (creatinine peak during aggressive diuresis)
    meta = mk_meta(P005, base, accession="AU-26-0451006",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-9939502",
                   collected="07/05/2026 06:05 EDT", received="07/05/2026 06:28 EDT",
                   reported="07/05/2026 07:15 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL (BMP) - REPEAT, HOSPITAL DAY 3",
         "tests": [
             ("Sodium", "134", "L", "mmol/L", "136 - 145"),
             ("Potassium", "4.0", "", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "97", "L", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "28", "", "mmol/L", "21 - 31"),
             ("BUN", "41", "H", "mg/dL", "7 - 25"),
             ("Creatinine", "1.58", "H", "mg/dL", "0.70 - 1.30"),
             ("eGFR (CKD-EPI 2021)", "45", "L", "mL/min/1.73m2", ">= 60"),
             ("Glucose", "98", "", "mg/dL", "70 - 99"),
         ],
         "comments": ["Repeat of BMP from 07/03/2026 16:33 EDT (accession AU-26-0450112). "
                      "Creatinine has risen from 1.42 to 1.58 mg/dL during aggressive diuresis, "
                      "consistent with expected transient cardiorenal physiology; continue to trend."]},
    ]
    emit_lab(folder, "P005_BMP_repeat_hospital_day3.pdf", hosp, P005, meta, panels, dx)

    # --- Repeat BMP, day of discharge
    meta = mk_meta(P005, base, accession="AU-26-0452118",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-9940871",
                   collected="07/09/2026 06:10 EDT", received="07/09/2026 06:33 EDT",
                   reported="07/09/2026 07:20 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL (BMP) - DISCHARGE DAY",
         "tests": [
             ("Sodium", "136", "", "mmol/L", "136 - 145"),
             ("Potassium", "4.3", "", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "99", "", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "26", "", "mmol/L", "21 - 31"),
             ("BUN", "29", "H", "mg/dL", "7 - 25"),
             ("Creatinine", "1.38", "H", "mg/dL", "0.70 - 1.30"),
             ("eGFR (CKD-EPI 2021)", "53", "L", "mL/min/1.73m2", ">= 60"),
             ("Glucose", "101", "", "mg/dL", "70 - 99"),
         ],
         "comments": ["Repeat of BMP from 07/05/2026 07:15 EDT (accession AU-26-0451006). "
                      "Creatinine and sodium trending toward baseline following completion of "
                      "decongestive therapy."]},
    ]
    emit_lab(folder, "P005_BMP_discharge_day.pdf", hosp, P005, meta, panels, dx)

    # CXR
    meta = mk_meta(P005, base, accession="AU-26-R034411", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   g8_label="Exam", g8_value="XR CHEST PORTABLE AP",
                   specimen="", collected="07/03/2026 15:20 EDT",
                   received="07/03/2026 15:20 EDT", reported="07/03/2026 16:05 EDT",
                   footer_right="PACS Study ID: 1.2.840.99.4410.20260703.6620")
    fields = [
        ("Exam", "XR CHEST, SINGLE VIEW, PORTABLE AP (CPT 71045)"),
        ("Indication", "74-year-old male with progressive dyspnea, orthopnea, and lower extremity "
                       "edema. Evaluate for pulmonary edema."),
        ("Technique", "Single portable AP upright radiograph of the chest."),
        ("Comparison", "Chest radiograph dated 02/17/2026."),
        ("Findings", "Moderate cardiomegaly, increased from prior. Pulmonary vascular congestion "
                     "with cephalization, perihilar haziness, and interstitial edema including "
                     "Kerley B lines at the lung bases. Small bilateral pleural effusions, right "
                     "greater than left. No focal consolidation to suggest pneumonia. No "
                     "pneumothorax. Median sternotomy wires absent; no prior cardiac surgery."),
    ]
    impression = [
        "Moderate cardiomegaly with interstitial pulmonary edema and small bilateral pleural effusions, consistent with acute decompensated heart failure.",
        "No focal consolidation.",
    ]
    sig = ["Dictated by: Marcus J. Bell, MD — Diagnostic Radiology (teleradiology coverage)",
           "Electronically signed by: <b>Marcus J. Bell, MD</b>   07/03/2026 16:05 EDT"]
    emit_rad(folder, "P005_chest_xray_portable.pdf", hosp, P005, meta, fields, impression, sig, dx)

    # Echo
    meta = mk_meta(P005, base, accession="AU-26-C007302", doctype="ECHOCARDIOGRAM REPORT",
                   department="Heart and Vascular Institute — Echocardiography Laboratory",
                   g8_label="Exam", g8_value="TTE COMPLETE W/ DOPPLER (CPT 93306)",
                   specimen="", collected="07/04/2026 09:40 EDT",
                   received="07/04/2026 09:40 EDT", reported="07/04/2026 12:10 EDT",
                   footer_right="IAC-Accredited Echocardiography Laboratory")
    fields = [
        ("Exam", "TRANSTHORACIC ECHOCARDIOGRAM, COMPLETE, WITH SPECTRAL AND COLOR DOPPLER"),
        ("Indication", "Acute decompensated heart failure. Assess LV function."),
        ("Technique", "2D, M-mode, spectral and color Doppler from standard windows. Image quality: adequate."),
        ("Findings", "Left ventricle: Severely reduced systolic function, estimated LVEF 25-30% "
                     "(biplane Simpson). Moderately dilated LV (LVIDd 6.3 cm) with global "
                     "hypokinesis, most pronounced anteroseptal. Grade III diastolic dysfunction "
                     "(restrictive filling, E/e' 18).\n\n"
                     "Right ventricle: Mildly reduced function (TAPSE 15 mm).\n\n"
                     "Atria: Moderate biatrial enlargement.\n\n"
                     "Valves: Moderate functional mitral regurgitation due to annular dilation. "
                     "Mild tricuspid regurgitation; estimated RVSP 48 mmHg (moderate pulmonary "
                     "hypertension).\n\n"
                     "Other: IVC dilated (2.4 cm) with < 50% inspiratory collapse, consistent with "
                     "elevated right atrial pressure. No pericardial effusion. No LV thrombus."),
    ]
    impression = [
        "Severely reduced LV systolic function, LVEF 25-30%, with LV dilation and global hypokinesis.",
        "Moderate functional mitral regurgitation; moderate pulmonary hypertension (RVSP 48 mmHg).",
        "Elevated right-sided filling pressures (dilated, non-collapsing IVC).",
        "Compared with study of 08/2025 (LVEF 35%), systolic function has declined.",
    ]
    sig = ["Sonographer: K. Brennan, RDCS",
           "Interpreted and electronically signed by: <b>Nina P. Vasquez, MD</b> — Level III Echocardiography   07/04/2026 12:10 EDT"]
    emit_rad(folder, "P005_echocardiogram_TTE.pdf", hosp, P005, meta, fields, impression, sig, dx)

    # Admission note
    nmeta = dict(department="Internal Medicine — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/03/2026",
                 encounter="CSN 55121808", attending="Thomas K. Adeyemi, MD, FACC",
                 unit="Cardiac Telemetry, 7-North", docid="NOTE-55121808-01",
                 printed="07/09/2026 11:30 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Progressive shortness of breath, orthopnea, and leg swelling x 1 week."),
        ("History of Present Illness",
         "Mr. Kowalski is a 74-year-old male with known ischemic cardiomyopathy (LVEF 35% in "
         "08/2025), hypertension, and remote 40 pack-year smoking history presenting with one "
         "week of progressive exertional dyspnea, three-pillow orthopnea, paroxysmal nocturnal "
         "dyspnea, and bilateral leg swelling with an 11-lb weight gain. He admits to dietary "
         "indiscretion over the holiday week (salted foods) and missing several furosemide "
         "doses. No chest pain, palpitations, syncope, fever, or cough. In the ED: BP 158/92, "
         "HR 96, RR 22, SpO2 90% RA improving on 2 L NC; JVD to the angle of the jaw; bibasilar "
         "crackles; 2+ pitting edema to the knees."),
        ("Past Medical History", ["Ischemic cardiomyopathy, HFrEF (LVEF 35%, 08/2025)",
                                  "Hypertension", "Remote MI (2019), medically managed",
                                  "Former tobacco use (40 pack-years, quit 2019)"]),
        ("Home Medications", {"table": (
            ["Medication", "Dose", "Route", "Frequency"],
            [["Furosemide", "40 mg", "PO", "BID"],
             ["Carvedilol", "12.5 mg", "PO", "BID"],
             ["Lisinopril", "10 mg", "PO", "Daily"],
             ["Aspirin", "81 mg", "PO", "Daily"],
             ["Atorvastatin", "40 mg", "PO", "Nightly"]],
            [0.34, 0.16, 0.16, 0.34])}),
        ("Diagnostic Data",
         "BNP 1,480 pg/mL. hs-Troponin I 28 -> 31 ng/L (no significant delta). Na 132, Cr 1.42 "
         "(baseline 1.1), BUN 34. CXR: interstitial pulmonary edema, cardiomegaly, small "
         "bilateral effusions. ECG: sinus rhythm, LBBB (old). TSH normal. CBC unremarkable."),
        ("Assessment and Plan",
         "74-year-old male with acute on chronic systolic heart failure (HFrEF), likely "
         "precipitated by dietary sodium excess and medication non-adherence. Warm-and-wet "
         "profile; no evidence of acute coronary syndrome (flat troponin).\n\n"
         "1. ADHF: IV furosemide 80 mg bolus then 40 mg IV q12h; strict I/O, daily weights, "
         "2 g sodium / 1.5 L fluid restriction. Goal net negative 1-2 L/day. Daily BMP.\n"
         "2. GDMT optimization: Continue carvedilol (compensated on presentation). Plan to "
         "transition lisinopril to sacubitril/valsartan after diuresis with 36-hour ACE-I "
         "washout. Add spironolactone 25 mg daily and dapagliflozin 10 mg daily if renal "
         "function permits.\n"
         "3. Hyponatremia (132): Dilutional; expect improvement with decongestion.\n"
         "4. Cardiorenal (Cr 1.42): Monitor with diuresis; hold nephrotoxins.\n"
         "5. Repeat TTE ordered. Telemetry monitoring. VTE prophylaxis: heparin 5,000 units SC q8h."),
    ]
    sig = ["Electronically signed by: <b>Sarah J. Lindqvist, MD</b> — Hospital Medicine   07/03/2026 19:41 EDT",
           "Cosigned by: <b>Thomas K. Adeyemi, MD, FACC</b> — Cardiology Attending   07/04/2026 07:55 EDT"]
    emit_note(folder, "P005_admission_HP_note.pdf", hosp, P005, nmeta, sections, sig, dx)

    # Discharge summary
    nmeta = dict(department="Heart and Vascular Institute — Cardiology",
                 note_title="DISCHARGE SUMMARY",
                 status="Signed", service_date="07/03/2026 - 07/09/2026",
                 encounter="CSN 55121808", attending="Thomas K. Adeyemi, MD, FACC",
                 unit="Cardiac Telemetry, 7-North", docid="NOTE-55121808-14",
                 printed="07/09/2026 13:05 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Admission / Discharge", "Admitted: 07/03/2026    Discharged: 07/09/2026    Length of stay: 6 days"),
        ("Discharge Diagnoses", [
            "Principal: Acute on chronic systolic (congestive) heart failure (I50.23)",
            "Secondary: Ischemic cardiomyopathy, LVEF 25-30% (I25.5)",
            "Secondary: Moderate functional mitral regurgitation (I34.0); Hyponatremia, resolved (E87.1)",
            "Chronic: Essential hypertension (I10); Old myocardial infarction (I25.2)"]),
        ("Hospital Course",
         "Mr. Kowalski was admitted with acute decompensated HFrEF (BNP 1,480) precipitated by "
         "dietary indiscretion and diuretic non-adherence. He was diuresed with IV furosemide "
         "(net -7.8 L; weight 96.2 -> 88.9 kg) with resolution of orthopnea, JVD, and edema. "
         "Echocardiogram showed LVEF 25-30%, declined from 35% in 08/2025, with moderate "
         "functional MR and moderate pulmonary hypertension. Troponin was flat; no ischemic "
         "event identified. GDMT was optimized: lisinopril was stopped (36-hr washout) and "
         "sacubitril/valsartan initiated at 24/26 mg BID, tolerated without hypotension "
         "(discharge BP 118/72); spironolactone 25 mg and dapagliflozin 10 mg were added; "
         "carvedilol continued. Creatinine peaked at 1.58 during diuresis and returned to 1.38 "
         "at discharge; sodium normalized to 136. PRIOR AUTHORIZATION for sacubitril/valsartan "
         "was submitted with this summary and the 07/04/2026 echocardiogram report "
         "(documented LVEF <= 40%, NYHA class III, ACE-I discontinued). He was evaluated for "
         "ICD candidacy; electrophysiology follow-up arranged after 3 months of optimized GDMT."),
        ("Discharge Medications", {"table": (
            ["Medication", "Dose", "Route", "Frequency", "Notes"],
            [["Sacubitril/valsartan", "24/26 mg", "PO", "BID", "New — titrate q2-4 wks to target 97/103 mg BID"],
             ["Carvedilol", "12.5 mg", "PO", "BID", "Continue"],
             ["Spironolactone", "25 mg", "PO", "Daily", "New — check K/Cr in 1 week"],
             ["Dapagliflozin", "10 mg", "PO", "Daily", "New"],
             ["Torsemide", "20 mg", "PO", "Daily", "New — replaces furosemide"],
             ["Aspirin", "81 mg", "PO", "Daily", "Continue"],
             ["Atorvastatin", "40 mg", "PO", "Nightly", "Continue"]],
            [0.24, 0.12, 0.08, 0.12, 0.44])}),
        ("Follow-Up and Instructions", [
            "Heart failure clinic in 7 days (07/16/2026, 1:30 PM) with BMP — monitor K and Cr on new spironolactone/ARNI.",
            "Daily weights; call HF clinic for gain > 3 lb in 1 day or > 5 lb in 1 week.",
            "Sodium restriction 2 g/day; fluid restriction 1.5 L/day. Dietitian consult completed inpatient.",
            "Electrophysiology consult in 3 months for ICD evaluation after GDMT optimization.",
            "Cardiology follow-up with Dr. Adeyemi in 4 weeks; repeat echocardiogram in 3 months."]),
        ("Condition at Discharge",
         "Euvolemic on examination, ambulating without dyspnea, SpO2 96% on room air. "
         "Discharge weight 88.9 kg. BP 118/72, HR 72."),
    ]
    sig = ["Electronically signed by: <b>Thomas K. Adeyemi, MD, FACC</b> — Attending Cardiologist   07/09/2026 12:40 EDT",
           "CC: Primary Care — Gerald Nowak, DO (via Direct secure message)"]
    emit_note(folder, "P005_discharge_summary.pdf", hosp, P005, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 6 — P006: Sepsis secondary to urinary tract infection (Meridian)
# ----------------------------------------------------------------------------
def case_p006():
    folder = os.path.join(OUT_ROOT, "P006_sepsis_urosepsis")
    os.makedirs(folder, exist_ok=True)
    hosp = MERIDIAN
    dx = "Sepsis secondary to urinary tract infection (ICD-10 A41.9)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0714402", encounter="CSN 88301274",
        ordering="Isabel R. Contreras, MD (NPI 1487203391)",
        attending="Marcus T. Whitfield, MD", client="MRMC-ED-021",
    )

    meta = mk_meta(P006, base, accession="MR-26-0201118",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-5512207",
                   collected="07/11/2026 03:15 EDT", received="07/11/2026 03:34 EDT",
                   reported="07/11/2026 04:10 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC) WITH DIFFERENTIAL",
         "tests": [
             ("WBC", "19.6", "H", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "11.8", "L", "g/dL", "12.0 - 15.5 (F)"),
             ("Platelet Count", "138", "L", "x10E3/uL", "150 - 400"),
             ("Neutrophils", "88.1", "H", "%", "40.0 - 70.0"),
             ("Lymphocytes", "6.2", "L", "%", "20.0 - 45.0"),
         ], "comments": []},
        {"name": "LACTATE, PLASMA",
         "tests": [("Lactate, Plasma", "4.2", "H", "mmol/L", "0.5 - 2.0")],
         "comments": ["Meets Sepsis-3 criteria for septic shock physiology (lactate > 2 mmol/L) "
                      "in the setting of suspected infection; repeat lactate ordered post-resuscitation."]},
    ]
    emit_lab(folder, "P006_CBC_lactate_initial.pdf", hosp, P006, meta, panels, dx)

    meta = mk_meta(P006, base, accession="MR-26-0201119",
                   specimen="Serum (SST, Gold) / Urine, Clean-Catch", specimen_id="SPX-5512208",
                   collected="07/11/2026 03:15 EDT", received="07/11/2026 03:34 EDT",
                   reported="07/11/2026 04:55 EDT")
    panels = [
        {"name": "COMPREHENSIVE METABOLIC PANEL (CMP)",
         "tests": [
             ("Sodium", "134", "L", "mmol/L", "136 - 145"),
             ("Potassium", "4.6", "", "mmol/L", "3.5 - 5.1"),
             ("BUN", "34", "H", "mg/dL", "7 - 25"),
             ("Creatinine", "1.8", "H", "mg/dL", "0.50 - 1.10"),
             ("eGFR (CKD-EPI 2021)", "29", "L", "mL/min/1.73m2", ">= 60"),
             ("Carbon Dioxide (CO2)", "18", "L", "mmol/L", "21 - 31"),
             ("Glucose", "142", "H", "mg/dL", "70 - 99"),
         ], "comments": ["Acute kidney injury superimposed on presumed sepsis-related hypoperfusion."]},
        {"name": "URINALYSIS",
         "tests": [
             ("Leukocyte Esterase", "Large", "H", "", "Negative"),
             ("Nitrite", "Positive", "H", "", "Negative"),
             ("WBC, Urine", "> 100", "H", "/hpf", "0 - 5"),
             ("Bacteria", "Many", "H", "", "None - Few"),
         ], "comments": ["Findings consistent with urinary tract infection as sepsis source; urine "
                         "culture pending, final result in 48-72 hours."]},
    ]
    emit_lab(folder, "P006_CMP_urinalysis.pdf", hosp, P006, meta, panels, dx)

    meta = mk_meta(P006, base, accession="MR-26-0201356",
                   specimen="Whole Blood (Point-of-Care)", specimen_id="SPX-5512260",
                   collected="07/11/2026 09:10 EDT", received="07/11/2026 09:14 EDT",
                   reported="07/11/2026 09:22 EDT")
    panels = [
        {"name": "LACTATE, PLASMA - REPEAT, POST-RESUSCITATION (6 HR)",
         "tests": [("Lactate, Plasma", "1.7", "", "mmol/L", "0.5 - 2.0")],
         "comments": ["Repeat of lactate from 07/11/2026 04:10 EDT (accession MR-26-0201118); "
                      "appropriate lactate clearance after 30 mL/kg crystalloid resuscitation, "
                      "consistent with resolving hypoperfusion."]},
    ]
    emit_lab(folder, "P006_lactate_repeat_6hr.pdf", hosp, P006, meta, panels, dx)

    meta = mk_meta(P006, base, accession="MR-26-R071889", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="CT ABDOMEN/PELVIS W/ CONTRAST",
                   collected="07/11/2026 05:30 EDT", received="07/11/2026 05:30 EDT",
                   reported="07/11/2026 07:15 EDT",
                   footer_right="PACS Study ID: 1.2.840.99.7215.20260711.5502")
    fields = [
        ("Exam", "CT ABDOMEN AND PELVIS WITH IV CONTRAST (CPT 74177)"),
        ("Indication", "75-year-old female with fever, flank pain, and pyuria; evaluate source of sepsis."),
        ("Technique", "Contiguous axial images obtained through the abdomen and pelvis following "
                      "IV contrast administration, with coronal and sagittal reformats."),
        ("Findings", "Right kidney demonstrates perinephric fat stranding and mild pyelocaliectasis, "
                     "without a discrete drainable abscess or obstructing calculus. Left kidney is "
                     "unremarkable. No hydronephrosis. No free air or free fluid. Appendix and "
                     "bowel loops are unremarkable."),
    ]
    impression = [
        "Findings consistent with acute right pyelonephritis without abscess or obstruction.",
        "No alternative surgical source of sepsis identified.",
    ]
    sig = ["Dictated by: Renee A. Falkner, MD — Diagnostic Radiology",
           "Electronically signed by: <b>Renee A. Falkner, MD</b>   07/11/2026 07:15 EDT"]
    emit_rad(folder, "P006_CT_abd_pelvis.pdf", hosp, P006, meta, fields, impression, sig, dx)

    nmeta = dict(department="Internal Medicine — Critical Care",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/11/2026",
                 encounter="CSN 88301274", attending="Marcus T. Whitfield, MD",
                 unit="Medical ICU", docid="NOTE-88301274-01",
                 printed="07/11/2026 11:20 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Fever, flank pain, and altered mentation, brought in from skilled nursing facility."),
        ("History of Present Illness",
         "Ms. Hayes is a 75-year-old female with a history of dementia and hypertension, resident "
         "of a skilled nursing facility, who presents with 1 day of fever, dysuria, and new "
         "confusion per facility staff. In the ED she was febrile to 39.4 C, hypotensive to 84/50 "
         "(responsive to 30 mL/kg lactated Ringer's), tachycardic to 118, and tachypneic to 24. "
         "qSOFA 2 (altered mentation, RR >= 22) and SIRS criteria met. Lactate 4.2 mmol/L. Urinalysis "
         "strongly positive for infection. Foley catheter in place from facility."),
        ("Past Medical History", ["Alzheimer dementia", "Hypertension", "Recurrent UTIs, "
                                  "chronic indwelling Foley catheter"]),
        ("Physical Examination",
         "Vitals (post-resuscitation): T 38.6 C, HR 104, BP 98/58, RR 20, SpO2 96% RA.\n\n"
         "General: Lethargic but arousable, oriented to person only (baseline per family). "
         "Cardiac: Tachycardic, regular. Lungs: Clear. Abdomen: Soft, mild suprapubic and right "
         "flank tenderness. Foley catheter draining cloudy urine. Extremities: No edema."),
        ("Diagnostic Data",
         "WBC 19.6 with 88.1% neutrophils, lactate 4.2 -> 1.7 after resuscitation, Cr 1.8 "
         "(baseline 0.9), UA with large leukocyte esterase and positive nitrite. CT abdomen/pelvis: "
         "right pyelonephritis without abscess or obstruction. Blood and urine cultures pending."),
        ("Assessment and Plan",
         "75-year-old female with sepsis (Sepsis-3 criteria met, source urinary/pyelonephritis) "
         "with acute kidney injury, admitted to the medical ICU.\n\n"
         "1. Sepsis, urinary source: Empiric ceftriaxone 2 g IV daily and vancomycin (renally dosed) "
         "pending culture data; continued fluid resuscitation guided by perfusion markers; Foley "
         "changed. Repeat lactate at 6 hours showed appropriate clearance (4.2 -> 1.7). 2. AKI: "
         "Likely prerenal/sepsis-related; trend creatinine, avoid nephrotoxins. 3. Delirium: "
         "Likely toxic-metabolic in setting of infection on baseline dementia; reorientation, "
         "avoid sedatives. 4. Code status: Full code per family. Disposition: MICU for 24-48 hours "
         "pending hemodynamic and mental status trend."),
    ]
    sig = ["Electronically signed by: <b>Marcus T. Whitfield, MD</b> — Critical Care Medicine   07/11/2026 11:05 EDT"]
    emit_note(folder, "P006_admission_HP_note.pdf", hosp, P006, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 7 — P007: COPD exacerbation (Ashford)
# ----------------------------------------------------------------------------
def case_p007():
    folder = os.path.join(OUT_ROOT, "P007_copd_exacerbation")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Acute exacerbation of chronic obstructive pulmonary disease (ICD-10 J44.1)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0716120", encounter="CSN 55142207",
        ordering="Grace Lin, MD (NPI 1720049823)",
        attending="Harold P. Vance, MD", client="AUMC-PULM-014",
    )

    meta = mk_meta(P007, base, accession="AU-26-0461102", doctype="BLOOD GAS REPORT",
                   specimen="Arterial Blood (Heparinized Syringe)", specimen_id="SPX-9911402",
                   g8_label="FiO2 / Device", g8_value="0.28 / Venturi Mask",
                   collected="07/13/2026 14:05 EDT", received="07/13/2026 14:09 EDT",
                   reported="07/13/2026 14:18 EDT")
    panels = [
        {"name": "ARTERIAL BLOOD GAS (VENTURI MASK 28%)",
         "performed": "Performed at: AUMC STAT Laboratory | Radiometer ABL90",
         "tests": [
             ("pH, Arterial", "7.29", "L", "", "7.35 - 7.45"),
             ("pCO2, Arterial", "68", "H", "mmHg", "35 - 45"),
             ("pO2, Arterial", "58", "L", "mmHg", "80 - 100"),
             ("Bicarbonate (HCO3), Calc", "30", "H", "mmol/L", "22 - 26"),
             ("Base Excess", "4.2", "H", "mmol/L", "-2.0 - +2.0"),
             ("O2 Saturation, Arterial", "88", "L", "%", "94 - 100"),
         ],
         "comments": ["Acute-on-chronic respiratory acidosis with hypoxemia, consistent with COPD "
                      "exacerbation. Recommend noninvasive ventilation and repeat ABG in 1-2 hours."]},
    ]
    emit_lab(folder, "P007_ABG_initial.pdf", hosp, P007, meta, panels, dx)

    meta = mk_meta(P007, base, accession="AU-26-0461145", doctype="BLOOD GAS REPORT",
                   specimen="Arterial Blood (Heparinized Syringe)", specimen_id="SPX-9911455",
                   g8_label="FiO2 / Device", g8_value="BiPAP 12/5, FiO2 0.40",
                   collected="07/13/2026 16:10 EDT", received="07/13/2026 16:14 EDT",
                   reported="07/13/2026 16:20 EDT")
    panels = [
        {"name": "ARTERIAL BLOOD GAS - REPEAT, 2 HR ON BiPAP",
         "tests": [
             ("pH, Arterial", "7.34", "L", "", "7.35 - 7.45"),
             ("pCO2, Arterial", "58", "H", "mmHg", "35 - 45"),
             ("pO2, Arterial", "72", "", "mmHg", "80 - 100"),
             ("Bicarbonate (HCO3), Calc", "29", "H", "mmol/L", "22 - 26"),
             ("O2 Saturation, Arterial", "93", "L", "%", "94 - 100"),
         ],
         "comments": ["Repeat of ABG from 07/13/2026 14:18 EDT (accession AU-26-0461102) after 2 "
                      "hours of BiPAP; interval improvement in respiratory acidosis and hypoxemia."]},
    ]
    emit_lab(folder, "P007_ABG_repeat_2hr.pdf", hosp, P007, meta, panels, dx)

    meta = mk_meta(P007, base, accession="AU-26-0461190",
                   specimen="Serum (SST, Gold) / EDTA WB", specimen_id="SPX-9911480",
                   collected="07/13/2026 14:05 EDT", received="07/13/2026 14:30 EDT",
                   reported="07/13/2026 15:40 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "12.1", "H", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "15.2", "", "g/dL", "13.5 - 17.5 (M)"),
             ("Platelet Count", "260", "", "x10E3/uL", "150 - 400"),
         ], "comments": []},
        {"name": "BASIC METABOLIC PANEL (BMP)",
         "tests": [
             ("Creatinine", "1.05", "", "mg/dL", "0.70 - 1.30"),
             ("Carbon Dioxide (CO2)", "30", "H", "mmol/L", "21 - 31"),
             ("BNP", "145", "H", "pg/mL", "< 100"),
         ], "comments": ["Mildly elevated BNP is nonspecific in the setting of chronic pulmonary "
                         "disease and cor pulmonale; does not support acute decompensated heart "
                         "failure as the primary process."]},
    ]
    emit_lab(folder, "P007_CBC_BMP_BNP.pdf", hosp, P007, meta, panels, dx)

    meta = mk_meta(P007, base, accession="AU-26-R044031", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="XR CHEST PORTABLE AP",
                   collected="07/13/2026 14:40 EDT", received="07/13/2026 14:40 EDT",
                   reported="07/13/2026 15:20 EDT")
    fields = [
        ("Exam", "XR CHEST PORTABLE AP (CPT 71045)"),
        ("Indication", "68-year-old male with COPD, dyspnea, and hypercapnic respiratory failure."),
        ("Findings", "Lungs are hyperinflated with flattened hemidiaphragms, consistent with known "
                     "COPD. No focal consolidation. No pleural effusion. No pneumothorax. Heart size "
                     "is normal within limits of portable technique."),
    ]
    impression = ["Hyperinflation consistent with COPD; no acute infiltrate or effusion."]
    sig = ["Dictated by: Priya M. Anand, MD — Diagnostic Radiology",
           "Electronically signed by: <b>Priya M. Anand, MD</b>   07/13/2026 15:20 EDT"]
    emit_rad(folder, "P007_chest_xray_portable.pdf", hosp, P007, meta, fields, impression, sig, dx)

    nmeta = dict(department="Pulmonary and Critical Care Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/13/2026",
                 encounter="CSN 55142207", attending="Harold P. Vance, MD",
                 unit="4-East Pulmonary", docid="NOTE-55142207-01",
                 printed="07/13/2026 17:45 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Worsening shortness of breath and cough x 4 days."),
        ("History of Present Illness",
         "Mr. McAllister is a 68-year-old male with severe COPD (home O2 2L NC, FEV1 38% "
         "predicted) and a 45 pack-year smoking history who presents with a 4-day prodrome of "
         "increased dyspnea, cough with purulent sputum, and increased rescue inhaler use "
         "following an upper respiratory illness. In the ED he was in moderate respiratory "
         "distress with accessory muscle use; ABG showed acute-on-chronic hypercapnic respiratory "
         "acidosis with hypoxemia. Started on BiPAP with interval improvement."),
        ("Past Medical History", ["COPD, GOLD group E, home O2 dependent",
                                  "45 pack-year smoking history, quit 2020",
                                  "Hypertension"]),
        ("Physical Examination",
         "Vitals: T 37.6 C, HR 98, BP 142/84, RR 26 (improved to 20 on BiPAP), SpO2 93% on BiPAP.\n\n"
         "General: Using accessory muscles, improved since BiPAP initiation. Lungs: Diffuse "
         "expiratory wheezes, prolonged expiratory phase, decreased breath sounds bilaterally. "
         "Cardiac: RRR, no murmurs. Extremities: Trace edema, no clubbing cyanosis."),
        ("Assessment and Plan",
         "68-year-old male with severe COPD presenting with acute exacerbation and hypercapnic "
         "respiratory failure, improving on noninvasive ventilation.\n\n"
         "1. COPD exacerbation: BiPAP with wean as tolerated, scheduled ipratropium/albuterol "
         "nebulizers, methylprednisolone 40 mg IV daily x 5 days, azithromycin 500 mg IV/PO daily "
         "x 5 days for likely viral/bacterial trigger. Repeat ABG at 2 hours showed improvement. "
         "2. Hypercapnic respiratory failure: Continue BiPAP overnight, transition to home O2 "
         "settings as tolerated, pulmonology following. 3. BNP mildly elevated, felt nonspecific "
         "given cor pulmonale; no diuresis indicated at this time. 4. Smoking cessation counseling "
         "reinforced. Disposition: Pulmonary step-down unit."),
    ]
    sig = ["Electronically signed by: <b>Harold P. Vance, MD</b> — Pulmonary and Critical Care   07/13/2026 17:30 EDT"]
    emit_note(folder, "P007_admission_HP_note.pdf", hosp, P007, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 8 — P008: Acute gallstone pancreatitis (Meridian)
# ----------------------------------------------------------------------------
def case_p008():
    folder = os.path.join(OUT_ROOT, "P008_gallstone_pancreatitis")
    os.makedirs(folder, exist_ok=True)
    hosp = MERIDIAN
    dx = "Acute gallstone pancreatitis (ICD-10 K85.10)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0718876", encounter="CSN 88317742",
        ordering="Nathaniel Bloom, MD (NPI 1932008845)",
        attending="Priyanka Deshmukh, MD", client="MRMC-GI-009",
    )

    meta = mk_meta(P008, base, accession="MR-26-0203301",
                   specimen="Serum (SST, Gold) / EDTA WB", specimen_id="SPX-6612204",
                   collected="07/15/2026 02:20 EDT", received="07/15/2026 02:45 EDT",
                   reported="07/15/2026 03:50 EDT")
    panels = [
        {"name": "PANCREATIC ENZYMES",
         "tests": [
             ("Lipase", "1120", "H", "U/L", "11 - 82"),
             ("Amylase", "480", "H", "U/L", "28 - 100"),
         ], "comments": []},
        {"name": "HEPATIC FUNCTION PANEL",
         "tests": [
             ("AST (SGOT)", "210", "H", "U/L", "10 - 40"),
             ("ALT (SGPT)", "245", "H", "U/L", "9 - 46"),
             ("Alkaline Phosphatase", "165", "H", "U/L", "36 - 130"),
             ("Bilirubin, Total", "2.1", "H", "mg/dL", "0.2 - 1.2"),
             ("Bilirubin, Direct", "1.4", "H", "mg/dL", "0.0 - 0.3"),
         ], "comments": ["Cholestatic pattern with markedly elevated transaminases; supports a "
                         "gallstone/biliary etiology for the pancreatitis."]},
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "14.2", "H", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "13.1", "", "g/dL", "12.0 - 15.5 (F)"),
             ("Platelet Count", "310", "", "x10E3/uL", "150 - 400"),
         ], "comments": []},
    ]
    emit_lab(folder, "P008_lipase_LFTs_CBC.pdf", hosp, P008, meta, panels, dx)

    meta = mk_meta(P008, base, accession="MR-26-0203588",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-6612388",
                   collected="07/16/2026 05:50 EDT", received="07/16/2026 06:10 EDT",
                   reported="07/16/2026 07:05 EDT")
    panels = [
        {"name": "HEPATIC FUNCTION PANEL - REPEAT, HOSPITAL DAY 2",
         "tests": [
             ("AST (SGOT)", "142", "H", "U/L", "10 - 40"),
             ("ALT (SGPT)", "190", "H", "U/L", "9 - 46"),
             ("Alkaline Phosphatase", "150", "H", "U/L", "36 - 130"),
             ("Bilirubin, Total", "1.3", "H", "mg/dL", "0.2 - 1.2"),
             ("Triglycerides", "165", "", "mg/dL", "< 150"),
         ],
         "comments": ["Repeat of hepatic panel from 07/15/2026 03:50 EDT (accession MR-26-0203301); "
                      "downtrending transaminases and bilirubin support a resolving biliary "
                      "obstruction/passed stone. Triglycerides normal, excluding hypertriglyceridemia "
                      "as etiology."]},
    ]
    emit_lab(folder, "P008_LFTs_repeat_day2.pdf", hosp, P008, meta, panels, dx)

    meta = mk_meta(P008, base, accession="MR-26-R073390", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="US ABDOMEN, RIGHT UPPER QUADRANT",
                   collected="07/15/2026 06:10 EDT", received="07/15/2026 06:10 EDT",
                   reported="07/15/2026 07:00 EDT")
    fields = [
        ("Exam", "US ABDOMEN, RIGHT UPPER QUADRANT (CPT 76705)"),
        ("Indication", "47-year-old female with epigastric pain, elevated lipase, and cholestatic LFTs."),
        ("Findings", "Gallbladder contains multiple mobile echogenic gallstones, largest 1.4 cm, "
                     "without wall thickening or pericholecystic fluid. Common bile duct is mildly "
                     "prominent at 8 mm without a definite stone visualized, limited by overlying "
                     "bowel gas. Pancreas is partially visualized and not well assessed due to "
                     "bowel gas overlying the body and tail."),
    ]
    impression = [
        "Cholelithiasis without sonographic evidence of acute cholecystitis.",
        "Mildly prominent common bile duct, possibly reflecting recent stone passage; correlate "
        "with trending bilirubin, consider MRCP if it does not continue to downtrend.",
    ]
    sig = ["Dictated by: Simone K. Halvorsen, MD — Diagnostic Radiology",
           "Electronically signed by: <b>Simone K. Halvorsen, MD</b>   07/15/2026 07:00 EDT"]
    emit_rad(folder, "P008_RUQ_ultrasound.pdf", hosp, P008, meta, fields, impression, sig, dx)

    nmeta = dict(department="Gastroenterology — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/15/2026",
                 encounter="CSN 88317742", attending="Priyanka Deshmukh, MD",
                 unit="6-North Surgical/GI", docid="NOTE-88317742-01",
                 printed="07/16/2026 09:10 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Severe epigastric abdominal pain radiating to the back, with nausea and vomiting."),
        ("History of Present Illness",
         "Ms. Figueroa is a 47-year-old female with no significant prior medical history who "
         "presents with 12 hours of severe, constant epigastric pain radiating to the back, "
         "associated with nausea and non-bloody vomiting. Pain began after a large fatty meal. "
         "No prior similar episodes. No alcohol use. Lipase markedly elevated with a cholestatic "
         "liver pattern, and right upper quadrant ultrasound confirms cholelithiasis, supporting "
         "gallstone pancreatitis."),
        ("Past Medical History", ["Obesity (BMI 31)", "No prior abdominal surgery"]),
        ("Physical Examination",
         "Vitals: T 37.8 C, HR 108, BP 118/74, RR 20, SpO2 98% RA.\n\n"
         "General: Uncomfortable, mild distress. Abdomen: Soft, marked epigastric tenderness "
         "without rebound or guarding, mild distension, hypoactive bowel sounds. No Murphy sign "
         "elicited. Skin/sclerae: No jaundice."),
        ("Assessment and Plan",
         "47-year-old female with acute gallstone pancreatitis (lipase > 3x ULN, cholestatic LFTs, "
         "confirmed cholelithiasis on ultrasound), moderate severity by BISAP criteria.\n\n"
         "1. Acute pancreatitis: NPO initially, aggressive isotonic IV fluid resuscitation, IV "
         "opioid analgesia, antiemetics. Repeat LFTs at 24 hours showed appropriate downtrend. "
         "2. Gallstone disease: General surgery consulted; plan for laparoscopic cholecystectomy "
         "prior to discharge, same admission, per standard of care for gallstone pancreatitis. "
         "MRCP to be considered if bilirubin fails to continue downtrending or if cholangitis "
         "develops. 3. Nutrition: Advance diet as tolerated once pain improving and lipase "
         "downtrending. Disposition: Continue inpatient monitoring, surgery within this admission."),
    ]
    sig = ["Electronically signed by: <b>Priyanka Deshmukh, MD</b> — Hospital Medicine   07/16/2026 08:50 EDT",
           "CC: General Surgery — Walter B. Osgood, MD"]
    emit_note(folder, "P008_admission_HP_note.pdf", hosp, P008, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 9 — P009: Diabetic ketoacidosis (Ashford)
# ----------------------------------------------------------------------------
def case_p009():
    folder = os.path.join(OUT_ROOT, "P009_dka")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Diabetic ketoacidosis, type 1 diabetes mellitus (ICD-10 E10.10)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0721004", encounter="CSN 55160918",
        ordering="Diane K. Osei, MD (NPI 1720337790)",
        attending="Rebecca Toussaint, MD", client="AUMC-ED-118",
    )

    meta = mk_meta(P009, base, accession="AU-26-0463210",
                   specimen="Serum (SST, Gold) / Venous Blood", specimen_id="SPX-7712004",
                   collected="07/17/2026 22:10 EDT", received="07/17/2026 22:20 EDT",
                   reported="07/17/2026 22:52 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL (BMP)",
         "tests": [
             ("Sodium", "131", "L", "mmol/L", "136 - 145"),
             ("Potassium", "5.6", "H", "mmol/L", "3.5 - 5.1"),
             ("Chloride", "92", "L", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "9", "L", "mmol/L", "21 - 31"),
             ("BUN", "22", "", "mg/dL", "7 - 25"),
             ("Creatinine", "1.3", "H", "mg/dL", "0.70 - 1.30"),
             ("Glucose", "512", "H", "mg/dL", "70 - 99"),
             ("Anion Gap, Calculated", "30", "H", "mmol/L", "8 - 16"),
         ], "comments": []},
        {"name": "VENOUS BLOOD GAS",
         "tests": [
             ("pH, Venous", "7.11", "L", "", "7.32 - 7.42"),
             ("pCO2, Venous", "22", "L", "mmHg", "41 - 51"),
             ("Bicarbonate (HCO3), Calc", "8", "L", "mmol/L", "22 - 26"),
         ], "comments": []},
        {"name": "KETONES",
         "tests": [
             ("Beta-Hydroxybutyrate", "6.8", "H", "mmol/L", "< 0.6"),
             ("Serum Ketones, Qualitative", "Positive (Large)", "H", "", "Negative"),
         ],
         "comments": ["Severe anion-gap metabolic acidosis with markedly elevated "
                      "beta-hydroxybutyrate and hyperglycemia, consistent with diabetic "
                      "ketoacidosis. Initiate DKA protocol: IV insulin infusion, aggressive IVF, "
                      "and potassium repletion once urine output confirmed, given total-body "
                      "potassium deficit despite initial hyperkalemia."]},
    ]
    emit_lab(folder, "P009_BMP_VBG_ketones_initial.pdf", hosp, P009, meta, panels, dx)

    meta = mk_meta(P009, base, accession="AU-26-0463255",
                   specimen="Serum (SST, Gold) / Venous Blood", specimen_id="SPX-7712061",
                   collected="07/18/2026 02:15 EDT", received="07/18/2026 02:19 EDT",
                   reported="07/18/2026 02:35 EDT")
    panels = [
        {"name": "BMP + VENOUS BLOOD GAS - REPEAT, 4 HR ON INSULIN INFUSION",
         "tests": [
             ("Sodium", "135", "", "mmol/L", "136 - 145"),
             ("Potassium", "4.1", "", "mmol/L", "3.5 - 5.1"),
             ("Carbon Dioxide (CO2)", "15", "L", "mmol/L", "21 - 31"),
             ("Glucose", "268", "H", "mg/dL", "70 - 99"),
             ("Anion Gap, Calculated", "16", "H", "mmol/L", "8 - 16"),
             ("pH, Venous", "7.24", "L", "", "7.32 - 7.42"),
             ("Bicarbonate (HCO3), Calc", "14", "L", "mmol/L", "22 - 26"),
         ],
         "comments": ["Repeat of BMP/VBG from 07/17/2026 22:52 EDT (accession AU-26-0463210); "
                      "anion gap closing appropriately (30 -> 16) on insulin infusion with dextrose "
                      "added to fluids given glucose < 250-300 mg/dL threshold approaching; "
                      "continue current protocol."]},
    ]
    emit_lab(folder, "P009_BMP_VBG_repeat_4hr.pdf", hosp, P009, meta, panels, dx)

    meta = mk_meta(P009, base, accession="AU-26-0463299",
                   specimen="Serum (SST, Gold) / Venous Blood", specimen_id="SPX-7712098",
                   collected="07/18/2026 06:20 EDT", received="07/18/2026 06:24 EDT",
                   reported="07/18/2026 06:40 EDT")
    panels = [
        {"name": "BMP + VENOUS BLOOD GAS - REPEAT, 8 HR ON INSULIN INFUSION",
         "tests": [
             ("Sodium", "138", "", "mmol/L", "136 - 145"),
             ("Potassium", "4.0", "", "mmol/L", "3.5 - 5.1"),
             ("Carbon Dioxide (CO2)", "21", "", "mmol/L", "21 - 31"),
             ("Glucose", "174", "H", "mg/dL", "70 - 99"),
             ("Anion Gap, Calculated", "11", "", "mmol/L", "8 - 16"),
             ("pH, Venous", "7.32", "", "", "7.32 - 7.42"),
             ("Bicarbonate (HCO3), Calc", "20", "L", "mmol/L", "22 - 26"),
         ],
         "comments": ["Repeat of BMP/VBG from 07/18/2026 02:35 EDT (accession AU-26-0463255). DKA "
                      "resolution criteria met (anion gap <= 12, venous pH > 7.30, bicarbonate "
                      ">= 18); transition to basal-bolus subcutaneous insulin per protocol with a "
                      "2-hour overlap of the IV infusion."]},
    ]
    emit_lab(folder, "P009_BMP_VBG_repeat_8hr.pdf", hosp, P009, meta, panels, dx)

    nmeta = dict(department="Internal Medicine — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/17/2026",
                 encounter="CSN 55160918", attending="Rebecca Toussaint, MD",
                 unit="Medical ICU Step-Down", docid="NOTE-55160918-01",
                 printed="07/18/2026 09:15 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Nausea, vomiting, abdominal pain, and polyuria x 2 days."),
        ("History of Present Illness",
         "Mr. Nguyen is a 36-year-old male with type 1 diabetes mellitus (diagnosed age 19) who "
         "presents with 2 days of nausea, vomiting, polyuria, and polydipsia, reporting he ran out "
         "of insulin 3 days ago. In the ED he was tachycardic and tachypneic with Kussmaul "
         "respirations, glucose 512 mg/dL, severe anion-gap metabolic acidosis, and large serum "
         "ketones, consistent with diabetic ketoacidosis. DKA protocol initiated with IV insulin "
         "infusion and aggressive fluid resuscitation."),
        ("Past Medical History", ["Type 1 diabetes mellitus, diagnosed 2009", "No prior DKA episodes"]),
        ("Physical Examination",
         "Vitals: T 37.2 C, HR 118, BP 102/64, RR 28 (Kussmaul pattern), SpO2 99% RA.\n\n"
         "General: Ill-appearing, fruity breath odor. Cardiac: Tachycardic, regular. Lungs: Clear, "
         "deep rapid respirations. Abdomen: Mild diffuse tenderness, no rebound/guarding. "
         "Neuro: Alert and oriented x 4."),
        ("Assessment and Plan",
         "36-year-old male with type 1 diabetes mellitus presenting in diabetic ketoacidosis, "
         "precipitated by insulin non-adherence due to lapse in supply.\n\n"
         "1. DKA: IV regular insulin infusion per weight-based protocol, hourly point-of-care "
         "glucose, serial BMP/VBG at 4 and 8 hours demonstrating anion gap closure (30 -> 16 -> 11) "
         "and improving pH; potassium repleted despite initial hyperkalemia given expected "
         "intracellular shift with insulin therapy; dextrose added to fluids once glucose < 250 "
         "mg/dL. Resolution criteria met at 8 hours; transitioned to basal-bolus subcutaneous "
         "insulin. 2. Precipitant: Insulin access/adherence counseling, social work and diabetes "
         "educator consulted, pharmacy assistance program referral. 3. Disposition: Step-down "
         "monitoring overnight, transfer to general medicine floor once tolerating oral intake."),
    ]
    sig = ["Electronically signed by: <b>Rebecca Toussaint, MD</b> — Hospital Medicine   07/18/2026 09:00 EDT"]
    emit_note(folder, "P009_admission_HP_note.pdf", hosp, P009, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 10 — P010: Acute ischemic stroke (Meridian)
# ----------------------------------------------------------------------------
def case_p010():
    folder = os.path.join(OUT_ROOT, "P010_ischemic_stroke")
    os.makedirs(folder, exist_ok=True)
    hosp = MERIDIAN
    dx = "Acute ischemic stroke, left MCA territory (ICD-10 I63.9)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0724551", encounter="CSN 88331560",
        ordering="Samuel O. Ibe, MD (NPI 1932445210)",
        attending="Camille R. Foster, MD", client="MRMC-NEURO-027",
    )

    meta = mk_meta(P010, base, accession="MR-26-0205112",
                   specimen="Serum (SST) / EDTA WB / Citrate", specimen_id="SPX-8813302",
                   collected="07/19/2026 08:02 EDT", received="07/19/2026 08:20 EDT",
                   reported="07/19/2026 08:55 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "8.1", "", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "12.4", "L", "g/dL", "12.0 - 15.5 (F)"),
             ("Platelet Count", "245", "", "x10E3/uL", "150 - 400"),
         ], "comments": []},
        {"name": "BASIC METABOLIC PANEL (BMP)",
         "tests": [
             ("Glucose", "142", "H", "mg/dL", "70 - 99"),
             ("Creatinine", "0.9", "", "mg/dL", "0.50 - 1.10"),
         ], "comments": []},
        {"name": "COAGULATION STUDIES",
         "tests": [
             ("PT", "12.8", "", "sec", "11.0 - 14.0"),
             ("INR", "1.0", "", "", "0.9 - 1.1"),
             ("PTT", "28", "", "sec", "25 - 35"),
         ], "comments": ["Coagulation parameters within normal limits; no contraindication to "
                         "thrombolysis on coagulation grounds."]},
        {"name": "LIPID PANEL",
         "tests": [
             ("LDL Cholesterol, Calculated", "138", "H", "mg/dL", "< 100"),
             ("HDL Cholesterol", "39", "L", "mg/dL", "> 50"),
             ("Triglycerides", "160", "H", "mg/dL", "< 150"),
         ], "comments": []},
    ]
    emit_lab(folder, "P010_stroke_labs_initial.pdf", hosp, P010, meta, panels, dx)

    meta = mk_meta(P010, base, accession="MR-26-0205400",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-8813510",
                   collected="07/20/2026 07:10 EDT", received="07/20/2026 07:30 EDT",
                   reported="07/20/2026 08:05 EDT")
    panels = [
        {"name": "CBC - REPEAT, HOSPITAL DAY 2 (POST-tPA SURVEILLANCE)",
         "tests": [
             ("WBC", "7.6", "", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "12.1", "L", "g/dL", "12.0 - 15.5 (F)"),
             ("Platelet Count", "238", "", "x10E3/uL", "150 - 400"),
         ],
         "comments": ["Repeat of CBC from 07/19/2026 08:55 EDT (accession MR-26-0205112); "
                      "hemoglobin and platelet count stable, no laboratory evidence of hemorrhage; "
                      "correlate with follow-up brain imaging."]},
    ]
    emit_lab(folder, "P010_CBC_repeat_day2.pdf", hosp, P010, meta, panels, dx)

    meta = mk_meta(P010, base, accession="MR-26-R074502", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="CT HEAD WITHOUT CONTRAST",
                   collected="07/19/2026 08:10 EDT", received="07/19/2026 08:10 EDT",
                   reported="07/19/2026 08:35 EDT")
    fields = [
        ("Exam", "CT HEAD WITHOUT CONTRAST (CPT 70450)"),
        ("Indication", "77-year-old female with acute-onset right-sided weakness and aphasia; evaluate for hemorrhage prior to thrombolysis."),
        ("Findings", "No acute intracranial hemorrhage. Subtle loss of gray-white differentiation "
                     "along the left insular ribbon, suggestive of very early ischemic change. "
                     "No midline shift. Ventricles are normal in size. ASPECTS score 9."),
    ]
    impression = [
        "No hemorrhage.",
        "Subtle early ischemic changes in the left MCA territory (insular ribbon); patient "
        "otherwise a candidate for thrombolysis within the appropriate time window given ASPECTS 9.",
    ]
    sig = ["Dictated by: Owen L. Marchetti, MD — Diagnostic Radiology (Neuroradiology)",
           "Electronically signed by: <b>Owen L. Marchetti, MD</b>   07/19/2026 08:35 EDT"]
    emit_rad(folder, "P010_CT_head_noncontrast.pdf", hosp, P010, meta, fields, impression, sig, dx)

    meta = mk_meta(P010, base, accession="MR-26-R074711", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="MRI BRAIN WITH DIFFUSION (DWI)",
                   collected="07/20/2026 09:00 EDT", received="07/20/2026 09:00 EDT",
                   reported="07/20/2026 10:15 EDT")
    fields = [
        ("Exam", "MRI BRAIN WITHOUT CONTRAST, WITH DIFFUSION-WEIGHTED IMAGING (CPT 70551)"),
        ("Indication", "Confirm and characterize infarct following IV thrombolysis, hospital day 2."),
        ("Findings", "Diffusion restriction involving the left insular cortex and corona radiata, "
                     "measuring approximately 2.5 x 1.8 cm, consistent with an acute infarct in the "
                     "left MCA (lenticulostriate/insular) distribution. No susceptibility artifact "
                     "to suggest hemorrhagic transformation. No additional acute infarcts."),
    ]
    impression = ["Acute left MCA territory infarct without hemorrhagic transformation."]
    sig = ["Dictated by: Owen L. Marchetti, MD — Diagnostic Radiology (Neuroradiology)",
           "Electronically signed by: <b>Owen L. Marchetti, MD</b>   07/20/2026 10:15 EDT"]
    emit_rad(folder, "P010_MRI_brain_DWI.pdf", hosp, P010, meta, fields, impression, sig, dx)

    nmeta = dict(department="Neurology — Stroke Service",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/19/2026",
                 encounter="CSN 88331560", attending="Camille R. Foster, MD",
                 unit="Neuro Stroke Unit", docid="NOTE-88331560-01",
                 printed="07/19/2026 12:40 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Acute-onset right-sided weakness and difficulty speaking."),
        ("History of Present Illness",
         "Ms. Barnes is a 77-year-old female with hypertension and hyperlipidemia, last known well "
         "at 07:15, found by family at 07:45 with right facial droop, right arm/leg weakness, and "
         "expressive aphasia. NIHSS 11 on arrival. CT head without contrast showed no hemorrhage "
         "with ASPECTS 9. Given time from last known well (within window), IV alteplase "
         "administered at 08:50 without immediate complication."),
        ("Past Medical History", ["Hypertension", "Hyperlipidemia", "No prior stroke or TIA"]),
        ("Physical Examination",
         "Vitals: BP 168/92, HR 84, RR 18, SpO2 97% RA.\n\n"
         "Neuro: Expressive aphasia, right facial droop, right upper extremity 2/5 strength, right "
         "lower extremity 3/5 strength, right-sided hyperreflexia. NIHSS 11 at presentation, "
         "improved to 6 by 4 hours post-tPA."),
        ("Diagnostic Data",
         "CT head: no hemorrhage, ASPECTS 9. MRI brain with DWI (hospital day 2): acute left MCA "
         "territory infarct without hemorrhagic transformation. Repeat CBC at 24 hours stable, no "
         "evidence of bleeding. Coagulation studies at baseline were normal, permitting thrombolysis."),
        ("Assessment and Plan",
         "77-year-old female with acute ischemic stroke, left MCA territory, treated with IV "
         "alteplase within the therapeutic window, with subsequent clinical improvement.\n\n"
         "1. Acute ischemic stroke: Post-tPA neurologic checks per protocol, blood pressure "
         "managed per post-thrombolysis parameters, no antiplatelet/anticoagulant for 24 hours "
         "then start aspirin 81 mg daily pending repeat imaging (obtained, no hemorrhage). "
         "2. Stroke workup: Echocardiogram and carotid duplex ordered to evaluate embolic source; "
         "telemetry for atrial fibrillation. 3. Secondary prevention: High-intensity statin "
         "initiated (atorvastatin 80 mg), blood pressure goal < 140/90 after acute period. "
         "4. Rehabilitation: PT/OT/speech-language pathology consulted for aphasia and hemiparesis. "
         "Disposition: Stroke unit monitoring, anticipate acute rehabilitation placement."),
    ]
    sig = ["Electronically signed by: <b>Camille R. Foster, MD</b> — Vascular Neurology   07/19/2026 12:20 EDT"]
    emit_note(folder, "P010_admission_HP_note.pdf", hosp, P010, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 11 — P011: Cellulitis with bacteremia (Ashford)
# ----------------------------------------------------------------------------
def case_p011():
    folder = os.path.join(OUT_ROOT, "P011_cellulitis_bacteremia")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Cellulitis of left lower extremity with Staphylococcus aureus bacteremia (ICD-10 L03.116)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0727390", encounter="CSN 55178204",
        ordering="Patricia N. Guerrero, MD (NPI 1720558832)",
        attending="Owen T. Marsh, MD", client="AUMC-ID-052",
    )

    meta = mk_meta(P011, base, accession="AU-26-0466410",
                   specimen="Whole Blood (EDTA, Lavender) / Serum", specimen_id="SPX-8820011",
                   collected="07/21/2026 11:40 EDT", received="07/21/2026 12:00 EDT",
                   reported="07/21/2026 12:45 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "16.9", "H", "x10E3/uL", "4.0 - 11.0"),
             ("Neutrophils", "82.0", "H", "%", "40.0 - 70.0"),
             ("Platelet Count", "190", "", "x10E3/uL", "150 - 400"),
         ], "comments": []},
        {"name": "INFLAMMATORY MARKERS",
         "tests": [("C-Reactive Protein (CRP)", "188", "H", "mg/L", "0.0 - 8.0")],
         "comments": ["Leukocytosis with neutrophilic predominance and markedly elevated CRP, "
                      "consistent with bacterial soft-tissue infection; blood cultures x 2 sets "
                      "collected this draw, pending."]},
    ]
    emit_lab(folder, "P011_CBC_CRP_initial.pdf", hosp, P011, meta, panels, dx)

    meta = mk_meta(P011, base, accession="AU-26-0466455", doctype="MICROBIOLOGY REPORT",
                   specimen="Blood Culture, Aerobic + Anaerobic (x2 Sets)", specimen_id="SPX-8820044",
                   collected="07/21/2026 11:40 EDT", received="07/21/2026 12:05 EDT",
                   reported="07/22/2026 06:20 EDT")
    panels = [
        {"name": "BLOOD CULTURE - PRELIMINARY REPORT",
         "tests": [("Gram Stain, Bottle 1 of 2 (Aerobic)", "Positive: Gram-positive cocci in clusters", "H", "", "No growth")],
         "comments": ["Preliminary Gram stain only; final identification and susceptibilities "
                      "pending, approximately 48-72 additional hours. Empiric coverage for "
                      "Staphylococcus/Streptococcus species recommended pending final ID."]},
    ]
    emit_lab(folder, "P011_blood_culture_preliminary.pdf", hosp, P011, meta, panels, dx)

    meta = mk_meta(P011, base, accession="AU-26-0466780", doctype="MICROBIOLOGY REPORT",
                   specimen="Blood Culture, Aerobic + Anaerobic (x2 Sets)", specimen_id="SPX-8820044",
                   collected="07/21/2026 11:40 EDT", received="07/21/2026 12:05 EDT",
                   reported="07/24/2026 09:15 EDT")
    panels = [
        {"name": "BLOOD CULTURE - FINAL REPORT",
         "tests": [("Organism Identified", "Staphylococcus aureus, methicillin-susceptible (MSSA)", "H", "", "No growth"),
                   ("Bottles Positive", "2 of 2", "", "", "0 of 2")],
         "comments": ["Susceptibilities: Oxacillin S, Cefazolin S, Vancomycin S, Clindamycin S, "
                      "Erythromycin R. Repeat/final result of preliminary Gram stain reported "
                      "07/22/2026 06:20 EDT (accession AU-26-0466455). Recommend narrowing empiric "
                      "therapy to cefazolin per susceptibilities; infectious disease and cardiology "
                      "consultation recommended to evaluate for endocarditis given S. aureus "
                      "bacteremia."]},
    ]
    emit_lab(folder, "P011_blood_culture_final.pdf", hosp, P011, meta, panels, dx)

    meta = mk_meta(P011, base, accession="AU-26-R044980", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="US SOFT TISSUE, LEFT LOWER EXTREMITY",
                   collected="07/21/2026 13:10 EDT", received="07/21/2026 13:10 EDT",
                   reported="07/21/2026 14:05 EDT")
    fields = [
        ("Exam", "US SOFT TISSUE AND VENOUS DOPPLER, LEFT LOWER EXTREMITY (CPT 76882/93970)"),
        ("Indication", "62-year-old male with left leg erythema, swelling, and bacteremia; evaluate for abscess and DVT."),
        ("Findings", "Diffuse subcutaneous edema and cobblestoning of the left lower leg, consistent "
                     "with cellulitis. No discrete drainable fluid collection or abscess identified. "
                     "Compression and color Doppler survey of the common femoral, femoral, and "
                     "popliteal veins demonstrate normal compressibility and flow; no evidence of "
                     "deep venous thrombosis."),
    ]
    impression = ["Cellulitis, left lower extremity, without discrete abscess.", "No deep venous thrombosis."]
    sig = ["Dictated by: Angela F. Prescott, MD — Diagnostic Radiology",
           "Electronically signed by: <b>Angela F. Prescott, MD</b>   07/21/2026 14:05 EDT"]
    emit_rad(folder, "P011_soft_tissue_US_LLE.pdf", hosp, P011, meta, fields, impression, sig, dx)

    nmeta = dict(department="Infectious Disease — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/21/2026",
                 encounter="CSN 55178204", attending="Owen T. Marsh, MD",
                 unit="3-South Medicine", docid="NOTE-55178204-01",
                 printed="07/21/2026 16:30 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Left leg redness, swelling, and fever x 2 days."),
        ("History of Present Illness",
         "Mr. Osei is a 62-year-old male with type 2 diabetes who presents with 2 days of "
         "progressive erythema, warmth, and swelling of the left lower leg following a minor "
         "abrasion, associated with fever to 39.0 C and chills. Blood cultures drawn in the ED "
         "grew gram-positive cocci in clusters on preliminary Gram stain, later confirmed as "
         "methicillin-susceptible Staphylococcus aureus in both bottles, consistent with cellulitis "
         "with secondary bacteremia."),
        ("Past Medical History", ["Type 2 diabetes mellitus", "Peripheral neuropathy"]),
        ("Physical Examination",
         "Vitals: T 38.7 C, HR 102, BP 128/76, RR 18, SpO2 97% RA.\n\n"
         "Skin: Left lower leg with well-demarcated erythema extending from the ankle to mid-calf, "
         "warm, tender, with mild non-pitting edema; no fluctuance, no crepitus, no skin "
         "breakdown or ulceration identified. Cardiac: RRR, no murmurs appreciated."),
        ("Assessment and Plan",
         "62-year-old male with left lower extremity cellulitis complicated by MSSA bacteremia.\n\n"
         "1. Cellulitis with bacteremia: Empiric vancomycin narrowed to cefazolin 2 g IV q8h once "
         "final susceptibilities resulted (MSSA, oxacillin-susceptible). Soft tissue ultrasound "
         "excluded abscess and DVT. Infectious disease consulted; transthoracic echocardiogram "
         "ordered to screen for endocarditis given S. aureus bacteremia (pending). Plan for 2 "
         "weeks of IV therapy given bacteremia, with transition to outpatient parenteral "
         "antibiotic therapy (OPAT) once afebrile and clinically improved. 2. Diabetes: Continue "
         "home regimen, monitor glucose given steroid-sparing infection. Disposition: Continue "
         "inpatient IV antibiotics pending repeat blood cultures to confirm clearance."),
    ]
    sig = ["Electronically signed by: <b>Owen T. Marsh, MD</b> — Hospital Medicine   07/21/2026 16:10 EDT",
           "CC: Infectious Disease — Farah N. Siddiqui, MD"]
    emit_note(folder, "P011_admission_HP_note.pdf", hosp, P011, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 12 — P012: Atrial fibrillation with rapid ventricular response (Meridian)
# ----------------------------------------------------------------------------
def case_p012():
    folder = os.path.join(OUT_ROOT, "P012_afib_rvr")
    os.makedirs(folder, exist_ok=True)
    hosp = MERIDIAN
    dx = "Atrial fibrillation with rapid ventricular response (ICD-10 I48.91)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0730118", encounter="CSN 88349901",
        ordering="Fatima Z. Rahman, MD (NPI 1932667712)",
        attending="Andrew T. Kessler, MD", client="MRMC-CARD-063",
    )

    meta = mk_meta(P012, base, accession="MR-26-0207220",
                   specimen="Serum (SST, Gold) / EDTA WB", specimen_id="SPX-9920210",
                   collected="07/24/2026 05:50 EDT", received="07/24/2026 06:10 EDT",
                   reported="07/24/2026 07:00 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "7.8", "", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "12.0", "L", "g/dL", "12.0 - 15.5 (F)"),
             ("Platelet Count", "210", "", "x10E3/uL", "150 - 400"),
         ], "comments": []},
        {"name": "BASIC METABOLIC PANEL (BMP)",
         "tests": [
             ("Potassium", "3.3", "L", "mmol/L", "3.5 - 5.1"),
             ("Magnesium", "1.4", "L", "mg/dL", "1.7 - 2.2"),
             ("Creatinine", "1.1", "", "mg/dL", "0.50 - 1.10"),
         ], "comments": []},
        {"name": "CARDIAC / ENDOCRINE STUDIES",
         "tests": [
             ("Troponin I, High-Sensitivity", "< 0.01", "", "ng/mL", "< 0.04"),
             ("TSH", "0.08", "L", "mIU/L", "0.45 - 4.50"),
         ],
         "comments": ["Suppressed TSH suggests hyperthyroidism as a possible precipitant for "
                      "atrial fibrillation with rapid ventricular response; recommend free T4/T3 "
                      "and endocrinology consultation. Hypokalemia and hypomagnesemia should be "
                      "repleted given proarrhythmic risk."]},
    ]
    emit_lab(folder, "P012_CBC_BMP_TSH_troponin.pdf", hosp, P012, meta, panels, dx)

    meta = mk_meta(P012, base, accession="MR-26-0207266",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-9920377",
                   collected="07/24/2026 14:00 EDT", received="07/24/2026 14:15 EDT",
                   reported="07/24/2026 14:50 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL - REPEAT, POST-REPLETION (8 HR)",
         "tests": [
             ("Potassium", "4.2", "", "mmol/L", "3.5 - 5.1"),
             ("Magnesium", "2.0", "", "mg/dL", "1.7 - 2.2"),
             ("Creatinine", "1.0", "", "mg/dL", "0.50 - 1.10"),
         ],
         "comments": ["Repeat of BMP from 07/24/2026 07:00 EDT (accession MR-26-0207220) following "
                      "IV potassium and magnesium repletion; electrolytes now within normal limits, "
                      "reducing proarrhythmic risk."]},
    ]
    emit_lab(folder, "P012_BMP_repeat_8hr.pdf", hosp, P012, meta, panels, dx)

    meta = mk_meta(P012, base, accession="MR-26-R075601", doctype="RADIOLOGY REPORT",
                   department="Department of Cardiology — ECG Laboratory",
                   specimen="", g8_label="Exam", g8_value="ECG, 12-LEAD",
                   collected="07/24/2026 05:45 EDT", received="07/24/2026 05:45 EDT",
                   reported="07/24/2026 06:00 EDT")
    fields = [
        ("Exam", "ELECTROCARDIOGRAM, 12-LEAD (CPT 93000)"),
        ("Indication", "81-year-old female with palpitations and irregular pulse."),
        ("Findings", "Irregularly irregular rhythm without discernible P waves, ventricular rate "
                     "148 bpm. QRS duration normal at 92 ms. No acute ST-segment or T-wave changes."),
    ]
    impression = ["Atrial fibrillation with rapid ventricular response, rate approximately 148 bpm."]
    sig = ["Electronically signed by: <b>Andrew T. Kessler, MD</b> — Cardiology   07/24/2026 06:00 EDT"]
    emit_rad(folder, "P012_ECG_12_lead.pdf", hosp, P012, meta, fields, impression, sig, dx)

    meta = mk_meta(P012, base, accession="MR-26-R075650", doctype="RADIOLOGY REPORT",
                   department="Department of Cardiology — Echocardiography Laboratory",
                   specimen="", g8_label="Exam", g8_value="TRANSTHORACIC ECHOCARDIOGRAM",
                   collected="07/25/2026 09:00 EDT", received="07/25/2026 09:00 EDT",
                   reported="07/25/2026 11:30 EDT")
    fields = [
        ("Exam", "TRANSTHORACIC ECHOCARDIOGRAM, COMPLETE (CPT 93306)"),
        ("Indication", "New-onset atrial fibrillation with rapid ventricular response; evaluate structural etiology."),
        ("Findings", "Left ventricular ejection fraction 58% (normal). Mild left atrial "
                     "enlargement (LA volume index 36 mL/m2). No significant valvular stenosis or "
                     "regurgitation. No intracardiac thrombus visualized on transthoracic views. "
                     "No pericardial effusion."),
    ]
    impression = ["Normal LV systolic function.", "Mild left atrial enlargement.",
                  "No valvular etiology identified for atrial fibrillation."]
    sig = ["Dictated by: Andrew T. Kessler, MD — Cardiology",
           "Electronically signed by: <b>Andrew T. Kessler, MD</b>   07/25/2026 11:30 EDT"]
    emit_rad(folder, "P012_echocardiogram_TTE.pdf", hosp, P012, meta, fields, impression, sig, dx)

    nmeta = dict(department="Cardiology — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/24/2026",
                 encounter="CSN 88349901", attending="Andrew T. Kessler, MD",
                 unit="Telemetry Unit", docid="NOTE-88349901-01",
                 printed="07/24/2026 09:40 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Palpitations, fatigue, and lightheadedness x 1 day."),
        ("History of Present Illness",
         "Ms. Schneider is an 81-year-old female with no prior cardiac history who presents with "
         "1 day of palpitations and fatigue. ECG showed atrial fibrillation with rapid ventricular "
         "response at 148 bpm. Labs notable for suppressed TSH, hypokalemia, and hypomagnesemia. "
         "Electrolytes repleted with interval normalization by 8 hours. Echocardiogram showed "
         "preserved ejection fraction without valvular etiology."),
        ("Past Medical History", ["No prior cardiac diagnoses", "Osteoporosis"]),
        ("Physical Examination",
         "Vitals: HR 128 (irregularly irregular), BP 132/78, RR 18, SpO2 97% RA.\n\n"
         "Cardiac: Irregularly irregular rhythm, no murmurs. Lungs: Clear. Extremities: No edema. "
         "Thyroid: Mildly enlarged, non-tender, no nodules palpated."),
        ("Assessment and Plan",
         "81-year-old female with new-onset atrial fibrillation with rapid ventricular response, "
         "likely precipitated by subclinical/overt hyperthyroidism, with concurrent hypokalemia "
         "and hypomagnesemia.\n\n"
         "1. Atrial fibrillation with RVR: Rate control with IV diltiazem, transitioned to oral "
         "diltiazem with good response (rate now 78-92 bpm). CHA2DS2-VASc score 4 (age, female "
         "sex, hypertension); anticoagulation with apixaban initiated after bleeding risk "
         "assessment. 2. Suppressed TSH: Free T4/T3 and thyroid antibodies sent; endocrinology "
         "consulted, outpatient follow-up arranged. 3. Electrolyte abnormalities: Repleted, "
         "repeat BMP at 8 hours normalized. 4. Disposition: Telemetry monitoring 24-48 hours, "
         "cardiology follow-up in 1-2 weeks with repeat TSH."),
    ]
    sig = ["Electronically signed by: <b>Andrew T. Kessler, MD</b> — Cardiology   07/24/2026 09:20 EDT"]
    emit_note(folder, "P012_admission_HP_note.pdf", hosp, P012, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 13 — P013: Acute upper gastrointestinal bleed (Ashford)
# ----------------------------------------------------------------------------
def case_p013():
    folder = os.path.join(OUT_ROOT, "P013_upper_gi_bleed")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Acute upper gastrointestinal bleed, duodenal ulcer (ICD-10 K26.4)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0733287", encounter="CSN 55196650",
        ordering="Brian K. Foley, MD (NPI 1720778904)",
        attending="Renata S. Alvarado, MD", client="AUMC-GI-071",
    )

    meta = mk_meta(P013, base, accession="AU-26-0469901",
                   specimen="Whole Blood (EDTA, Lavender) / Citrate", specimen_id="SPX-9933012",
                   collected="07/26/2026 03:30 EDT", received="07/26/2026 03:45 EDT",
                   reported="07/26/2026 04:10 EDT")
    panels = [
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "11.2", "H", "x10E3/uL", "4.0 - 11.0"),
             ("Hemoglobin", "8.9", "L", "g/dL", "13.5 - 17.5 (M)"),
             ("Hematocrit", "27.1", "L", "%", "41.0 - 50.0 (M)"),
             ("Platelet Count", "205", "", "x10E3/uL", "150 - 400"),
         ], "comments": []},
        {"name": "COAGULATION STUDIES",
         "tests": [("PT/INR", "13.0 / 1.1", "", "sec / ratio", "11.0-14.0 / 0.9-1.1"),
                   ("PTT", "30", "", "sec", "25 - 35")], "comments": []},
        {"name": "TYPE AND SCREEN",
         "tests": [("ABO/Rh Type", "O Positive", "", "", "N/A"),
                   ("Antibody Screen", "Negative", "", "", "Negative")],
         "comments": ["Acute blood loss anemia; type and screen completed for possible transfusion. "
                      "Gastroenterology consulted for urgent upper endoscopy."]},
    ]
    emit_lab(folder, "P013_CBC_coags_type_screen.pdf", hosp, P013, meta, panels, dx)

    meta = mk_meta(P013, base, accession="AU-26-0469955",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-9933077",
                   collected="07/26/2026 09:45 EDT", received="07/26/2026 09:50 EDT",
                   reported="07/26/2026 10:15 EDT")
    panels = [
        {"name": "CBC - REPEAT, POST-TRANSFUSION (6 HR)",
         "tests": [
             ("Hemoglobin", "10.4", "L", "g/dL", "13.5 - 17.5 (M)"),
             ("Hematocrit", "31.5", "L", "%", "41.0 - 50.0 (M)"),
             ("Platelet Count", "198", "", "x10E3/uL", "150 - 400"),
         ],
         "comments": ["Repeat of CBC from 07/26/2026 04:10 EDT (accession AU-26-0469901) following "
                      "transfusion of 2 units packed red blood cells; appropriate hemoglobin "
                      "increment, patient hemodynamically stable."]},
    ]
    emit_lab(folder, "P013_CBC_repeat_post_transfusion.pdf", hosp, P013, meta, panels, dx)

    meta = mk_meta(P013, base, accession="AU-26-0470048",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-9933145",
                   collected="07/27/2026 05:50 EDT", received="07/27/2026 06:00 EDT",
                   reported="07/27/2026 06:30 EDT")
    panels = [
        {"name": "CBC - REPEAT, HOSPITAL DAY 2",
         "tests": [
             ("Hemoglobin", "10.1", "L", "g/dL", "13.5 - 17.5 (M)"),
             ("Hematocrit", "30.6", "L", "%", "41.0 - 50.0 (M)"),
             ("Platelet Count", "210", "", "x10E3/uL", "150 - 400"),
         ],
         "comments": ["Repeat of CBC from 07/26/2026 10:15 EDT (accession AU-26-0469955); "
                      "hemoglobin stable without further transfusion requirement, no evidence of "
                      "rebleeding."]},
    ]
    emit_lab(folder, "P013_CBC_repeat_day2.pdf", hosp, P013, meta, panels, dx)

    meta = mk_meta(P013, base, accession="AU-26-R047230", doctype="ENDOSCOPY REPORT",
                   department="Division of Gastroenterology — Endoscopy Suite",
                   specimen="", g8_label="Exam", g8_value="EGD (ESOPHAGOGASTRODUODENOSCOPY)",
                   collected="07/26/2026 07:00 EDT", received="07/26/2026 07:00 EDT",
                   reported="07/26/2026 09:30 EDT")
    fields = [
        ("Exam", "ESOPHAGOGASTRODUODENOSCOPY (CPT 43235)"),
        ("Indication", "Melena and acute blood loss anemia with hemodynamic instability."),
        ("Findings", "Esophagus is normal in appearance without varices or esophagitis. Stomach "
                     "shows mild antral gastritis without active bleeding. Duodenal bulb "
                     "demonstrates a clean-based ulcer measuring 8 mm without active bleeding or "
                     "visible vessel (Forrest III)."),
    ]
    impression = [
        "Duodenal ulcer, Forrest III classification (low rebleed risk).",
        "No esophageal varices identified; portal hypertensive source unlikely.",
        "Recommend high-dose proton pump inhibitor therapy and testing for Helicobacter pylori.",
    ]
    sig = ["Performed by: Renata S. Alvarado, MD — Gastroenterology",
           "Electronically signed by: <b>Renata S. Alvarado, MD</b>   07/26/2026 09:30 EDT"]
    emit_rad(folder, "P013_EGD_report.pdf", hosp, P013, meta, fields, impression, sig, dx)

    nmeta = dict(department="Gastroenterology — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/26/2026",
                 encounter="CSN 55196650", attending="Renata S. Alvarado, MD",
                 unit="Medical ICU Step-Down", docid="NOTE-55196650-01",
                 printed="07/26/2026 11:50 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Melena and lightheadedness x 1 day."),
        ("History of Present Illness",
         "Mr. Morales is a 59-year-old male with chronic NSAID use for back pain who presents "
         "with 1 day of black tarry stools and lightheadedness. In the ED he was tachycardic to "
         "112 with orthostatic hypotension; hemoglobin 8.9 g/dL, down from a baseline of 14.2 g/dL "
         "6 months prior. Type and screen completed, 2 units packed red blood cells transfused "
         "with appropriate increment. Urgent EGD identified a clean-based duodenal ulcer without "
         "active bleeding."),
        ("Past Medical History", ["Chronic low back pain, chronic NSAID use", "No prior GI bleeding"]),
        ("Physical Examination",
         "Vitals (post-transfusion): T 37.1 C, HR 88, BP 118/70, RR 16, SpO2 98% RA.\n\n"
         "General: Pale conjunctivae. Abdomen: Soft, mild epigastric tenderness, no rebound or "
         "guarding. Rectal: Melanotic stool, no gross blood, no mass. Cardiac: RRR, no murmurs."),
        ("Assessment and Plan",
         "59-year-old male with acute upper gastrointestinal bleeding from an NSAID-associated "
         "duodenal ulcer, now endoscopically low-risk (Forrest III), transfused 2 units with "
         "appropriate hemoglobin response and no further drop over 24 hours.\n\n"
         "1. Upper GI bleed, duodenal ulcer: High-dose IV proton pump inhibitor transitioned to "
         "oral, discontinue NSAIDs permanently, H. pylori testing pending. Serial hemoglobin at 6 "
         "and 24 hours post-transfusion stable, no further transfusion required. 2. Anemia: "
         "Iron studies pending, consider oral iron supplementation at discharge. 3. Pain "
         "management: Transition back pain regimen to acetaminophen/topical agents, avoid "
         "NSAIDs indefinitely. Disposition: Downgrade from step-down to general medicine floor, "
         "anticipate discharge once tolerating diet with stable hemoglobin."),
    ]
    sig = ["Electronically signed by: <b>Renata S. Alvarado, MD</b> — Gastroenterology   07/26/2026 11:30 EDT"]
    emit_note(folder, "P013_admission_HP_note.pdf", hosp, P013, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 14 — P014: Severe hyperkalemia, ESRD on hemodialysis (Meridian)
# ----------------------------------------------------------------------------
def case_p014():
    folder = os.path.join(OUT_ROOT, "P014_hyperkalemia_esrd")
    os.makedirs(folder, exist_ok=True)
    hosp = MERIDIAN
    dx = "Severe hyperkalemia, end-stage renal disease on hemodialysis, missed session (ICD-10 E87.5)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0736004", encounter="CSN 88362817",
        ordering="Louis M. Ferretti, MD (NPI 1932891220)",
        attending="Devika R. Pillai, MD", client="MRMC-NEPH-038",
    )

    meta = mk_meta(P014, base, accession="MR-26-0209310",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-4471102",
                   collected="07/29/2026 16:20 EDT", received="07/29/2026 16:24 EDT",
                   reported="07/29/2026 16:35 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL (BMP) - STAT, CRITICAL VALUE",
         "tests": [
             ("Potassium", "7.2", "H", "mmol/L", "3.5 - 5.1"),
             ("Sodium", "138", "", "mmol/L", "136 - 145"),
             ("Chloride", "100", "", "mmol/L", "98 - 107"),
             ("Carbon Dioxide (CO2)", "18", "L", "mmol/L", "21 - 31"),
             ("BUN", "68", "H", "mg/dL", "7 - 25"),
             ("Creatinine", "6.4", "H", "mg/dL", "0.50 - 1.10"),
             ("Glucose", "110", "", "mg/dL", "70 - 99"),
         ],
         "comments": ["CRITICAL VALUE: Potassium 7.2 mmol/L phoned to Dr. Pillai at 16:36 EDT by "
                      "Meredith L. Chan, MT(ASCP), read back and confirmed, per critical value "
                      "policy. Patient is hemodialysis-dependent (ESRD); missed dialysis session "
                      "reported. Emergent treatment recommended (calcium gluconate, insulin/"
                      "dextrose, emergent hemodialysis)."]},
    ]
    emit_lab(folder, "P014_BMP_STAT_critical.pdf", hosp, P014, meta, panels, dx)

    meta = mk_meta(P014, base, accession="MR-26-0209344",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-4471140",
                   collected="07/29/2026 18:15 EDT", received="07/29/2026 18:19 EDT",
                   reported="07/29/2026 18:30 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL - REPEAT, PRE-DIALYSIS (2 HR)",
         "tests": [
             ("Potassium", "6.1", "H", "mmol/L", "3.5 - 5.1"),
             ("Carbon Dioxide (CO2)", "19", "L", "mmol/L", "21 - 31"),
             ("Creatinine", "6.5", "H", "mg/dL", "0.50 - 1.10"),
             ("Glucose", "168", "H", "mg/dL", "70 - 99"),
         ],
         "comments": ["Repeat of BMP from 07/29/2026 16:35 EDT (accession MR-26-0209310) after "
                      "calcium gluconate, IV insulin/dextrose, and nebulized albuterol; interval "
                      "reduction in potassium. Emergent hemodialysis now underway for definitive "
                      "potassium removal."]},
    ]
    emit_lab(folder, "P014_BMP_repeat_2hr_predialysis.pdf", hosp, P014, meta, panels, dx)

    meta = mk_meta(P014, base, accession="MR-26-0209388",
                   specimen="Serum (SST, Gold)", specimen_id="SPX-4471188",
                   collected="07/29/2026 22:40 EDT", received="07/29/2026 22:44 EDT",
                   reported="07/29/2026 22:55 EDT")
    panels = [
        {"name": "BASIC METABOLIC PANEL - REPEAT, POST-HEMODIALYSIS",
         "tests": [
             ("Potassium", "4.4", "", "mmol/L", "3.5 - 5.1"),
             ("Carbon Dioxide (CO2)", "24", "", "mmol/L", "21 - 31"),
             ("Creatinine", "4.1", "H", "mg/dL", "0.50 - 1.10"),
             ("Glucose", "132", "H", "mg/dL", "70 - 99"),
         ],
         "comments": ["Repeat of BMP from 07/29/2026 18:30 EDT (accession MR-26-0209344) following "
                      "a 3.5-hour hemodialysis session; potassium normalized to a safe range."]},
    ]
    emit_lab(folder, "P014_BMP_repeat_postdialysis.pdf", hosp, P014, meta, panels, dx)

    meta = mk_meta(P014, base, accession="MR-26-R076810", doctype="RADIOLOGY REPORT",
                   department="Department of Cardiology — ECG Laboratory",
                   specimen="", g8_label="Exam", g8_value="ECG, 12-LEAD",
                   collected="07/29/2026 16:22 EDT", received="07/29/2026 16:22 EDT",
                   reported="07/29/2026 16:30 EDT")
    fields = [
        ("Exam", "ELECTROCARDIOGRAM, 12-LEAD (CPT 93000)"),
        ("Indication", "66-year-old female with ESRD on hemodialysis, missed session, critical hyperkalemia."),
        ("Findings", "Peaked T waves in the precordial leads. PR interval mildly prolonged at 210 "
                     "ms. QRS duration borderline widened at 104 ms. P waves not clearly "
                     "discernible in several leads."),
    ]
    impression = ["ECG changes consistent with hyperkalemia; recommend correlation with STAT "
                  "potassium level and repeat ECG after treatment."]
    sig = ["Electronically signed by: <b>Devika R. Pillai, MD</b> — Nephrology   07/29/2026 16:30 EDT"]
    emit_rad(folder, "P014_ECG_hyperkalemia.pdf", hosp, P014, meta, fields, impression, sig, dx)

    nmeta = dict(department="Nephrology — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/29/2026",
                 encounter="CSN 88362817", attending="Devika R. Pillai, MD",
                 unit="Medical ICU", docid="NOTE-88362817-01",
                 printed="07/29/2026 23:20 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Generalized weakness and missed hemodialysis session."),
        ("History of Present Illness",
         "Ms. Abernathy is a 66-year-old female with end-stage renal disease on hemodialysis "
         "(Monday/Wednesday/Friday schedule) who presents after missing her most recent session "
         "due to transportation issues, with 1 day of generalized weakness and palpitations. STAT "
         "potassium was critically elevated at 7.2 mmol/L with corresponding ECG changes (peaked "
         "T waves). Treated emergently with calcium gluconate for cardiac membrane stabilization, "
         "IV insulin/dextrose, and nebulized albuterol, followed by emergent hemodialysis with "
         "normalization of potassium."),
        ("Past Medical History", ["End-stage renal disease, hemodialysis-dependent (3x/week)",
                                  "Hypertension", "Secondary hyperparathyroidism"]),
        ("Physical Examination",
         "Vitals: T 37.0 C, HR 58 (bradycardic on presentation), BP 156/88, RR 18, SpO2 98% RA.\n\n"
         "Cardiac: Regular bradycardia, no murmurs. Neuro: Alert, mild generalized weakness, no "
         "focal deficits. Extremities: Left forearm AV fistula with palpable thrill, no signs of "
         "infection."),
        ("Assessment and Plan",
         "66-year-old female with end-stage renal disease presenting with severe hyperkalemia "
         "(potassium 7.2 mmol/L) and ECG changes following a missed hemodialysis session, "
         "successfully treated with emergent stabilization and hemodialysis.\n\n"
         "1. Severe hyperkalemia: Calcium gluconate for membrane stabilization, IV insulin/"
         "dextrose and nebulized albuterol for transcellular shift, followed by emergent "
         "hemodialysis with normalization of potassium (7.2 -> 6.1 -> 4.4) and resolution of ECG "
         "changes. 2. ESRD: Resume standing Monday/Wednesday/Friday hemodialysis schedule; social "
         "work consulted to address transportation barrier. Dietary counseling reinforced "
         "regarding potassium restriction; hold home ACE inhibitor. 3. Disposition: Overnight "
         "monitoring with telemetry given hyperkalemia and bradycardia, transfer to general "
         "medicine floor once stable, resume outpatient dialysis schedule at discharge."),
    ]
    sig = ["Electronically signed by: <b>Devika R. Pillai, MD</b> — Nephrology   07/29/2026 23:05 EDT"]
    emit_note(folder, "P014_admission_HP_note.pdf", hosp, P014, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
# CASE 15 — P015: Acute pyelonephritis (Ashford)
# ----------------------------------------------------------------------------
def case_p015():
    folder = os.path.join(OUT_ROOT, "P015_acute_pyelonephritis")
    os.makedirs(folder, exist_ok=True)
    hosp = ASHFORD
    dx = "Acute pyelonephritis, right kidney, E. coli (ICD-10 N10)"
    base = dict(
        department="Department of Pathology and Laboratory Medicine",
        doctype="LABORATORY REPORT", status="FINAL",
        visit="V2026-0739215", encounter="CSN 55210347",
        ordering="Monica T. Vasquez, MD (NPI 1720990112)",
        attending="Diego F. Camarena, MD", client="AUMC-ED-133",
    )

    meta = mk_meta(P015, base, accession="AU-26-0472510",
                   specimen="Urine, Clean-Catch / EDTA WB / Serum", specimen_id="SPX-2210044",
                   collected="07/31/2026 10:15 EDT", received="07/31/2026 10:40 EDT",
                   reported="07/31/2026 11:30 EDT")
    panels = [
        {"name": "URINALYSIS",
         "tests": [
             ("Leukocyte Esterase", "Large", "H", "", "Negative"),
             ("Nitrite", "Positive", "H", "", "Negative"),
             ("WBC, Urine", "> 100", "H", "/hpf", "0 - 5"),
             ("RBC, Urine", "8", "H", "/hpf", "0 - 3"),
             ("Bacteria", "Many", "H", "", "None - Few"),
         ], "comments": []},
        {"name": "COMPLETE BLOOD COUNT (CBC)",
         "tests": [
             ("WBC", "13.8", "H", "x10E3/uL", "4.0 - 11.0"),
             ("Neutrophils", "79.0", "H", "%", "40.0 - 70.0"),
             ("Platelet Count", "275", "", "x10E3/uL", "150 - 400"),
         ], "comments": []},
        {"name": "BASIC METABOLIC PANEL (BMP)",
         "tests": [("Creatinine", "0.9", "", "mg/dL", "0.50 - 1.10"),
                   ("BUN", "14", "", "mg/dL", "7 - 25")],
         "comments": ["Findings consistent with acute pyelonephritis. Urine culture pending, "
                      "final result in 48-72 hours."]},
    ]
    emit_lab(folder, "P015_UA_CBC_CMP_initial.pdf", hosp, P015, meta, panels, dx)

    meta = mk_meta(P015, base, accession="AU-26-0472650",
                   specimen="Whole Blood (EDTA, Lavender)", specimen_id="SPX-2210091",
                   collected="08/01/2026 06:05 EDT", received="08/01/2026 06:20 EDT",
                   reported="08/01/2026 07:00 EDT")
    panels = [
        {"name": "CBC - REPEAT, HOSPITAL DAY 2",
         "tests": [
             ("WBC", "9.4", "", "x10E3/uL", "4.0 - 11.0"),
             ("Neutrophils", "68.0", "", "%", "40.0 - 70.0"),
             ("Platelet Count", "268", "", "x10E3/uL", "150 - 400"),
         ],
         "comments": ["Repeat of CBC from 07/31/2026 11:30 EDT (accession AU-26-0472510); "
                      "leukocytosis improving on IV ceftriaxone, patient afebrile since hospital "
                      "day 2."]},
    ]
    emit_lab(folder, "P015_CBC_repeat_day2.pdf", hosp, P015, meta, panels, dx)

    meta = mk_meta(P015, base, accession="AU-26-0472890", doctype="MICROBIOLOGY REPORT",
                   specimen="Urine, Clean-Catch", specimen_id="SPX-2210044",
                   collected="07/31/2026 10:15 EDT", received="07/31/2026 10:40 EDT",
                   reported="08/02/2026 09:20 EDT")
    panels = [
        {"name": "URINE CULTURE - FINAL REPORT",
         "tests": [("Organism Identified", "Escherichia coli, > 100,000 CFU/mL", "H", "", "No growth")],
         "comments": ["Susceptibilities: Ceftriaxone S, Nitrofurantoin S, Ampicillin R, "
                      "Ciprofloxacin R, Trimethoprim/Sulfamethoxazole R. Repeat/final result of "
                      "urine culture collected 07/31/2026 10:15 EDT (accession AU-26-0472510, "
                      "preliminary UA reported same day). Organism resistant to fluoroquinolones "
                      "and TMP-SMX; continue ceftriaxone with transition to an oral agent "
                      "consistent with susceptibilities (e.g., cefpodoxime) to complete a 7-day "
                      "course."]},
    ]
    emit_lab(folder, "P015_urine_culture_final.pdf", hosp, P015, meta, panels, dx)

    meta = mk_meta(P015, base, accession="AU-26-R048112", doctype="RADIOLOGY REPORT",
                   department="Department of Radiology",
                   specimen="", g8_label="Exam", g8_value="US RENAL, BILATERAL",
                   collected="07/31/2026 12:00 EDT", received="07/31/2026 12:00 EDT",
                   reported="07/31/2026 13:15 EDT")
    fields = [
        ("Exam", "US RENAL, BILATERAL (CPT 76770)"),
        ("Indication", "33-year-old female with fever, flank pain, and pyuria; evaluate for obstruction or abscess."),
        ("Findings", "Right kidney is mildly enlarged (11.8 cm) with increased parenchymal "
                     "echogenicity and loss of corticomedullary differentiation. No hydronephrosis. "
                     "No perinephric fluid collection or discrete abscess. Left kidney is normal "
                     "in size and echotexture without hydronephrosis."),
    ]
    impression = ["Findings compatible with acute right pyelonephritis.",
                  "No evidence of obstruction or abscess."]
    sig = ["Dictated by: Nadia R. Constantin, MD — Diagnostic Radiology",
           "Electronically signed by: <b>Nadia R. Constantin, MD</b>   07/31/2026 13:15 EDT"]
    emit_rad(folder, "P015_renal_ultrasound.pdf", hosp, P015, meta, fields, impression, sig, dx)

    nmeta = dict(department="Internal Medicine — Hospital Medicine",
                 note_title="HISTORY AND PHYSICAL (ADMISSION H&P)",
                 status="Signed", service_date="07/31/2026",
                 encounter="CSN 55210347", attending="Diego F. Camarena, MD",
                 unit="4-North Medicine", docid="NOTE-55210347-01",
                 printed="07/31/2026 15:40 EDT", footer_right="EHR Encounter Summary")
    sections = [
        ("Chief Complaint", "Fever, right flank pain, and dysuria x 2 days."),
        ("History of Present Illness",
         "Ms. Rivera is a 33-year-old female with no significant past medical history who "
         "presents with 2 days of fever, right flank pain, dysuria, and urinary frequency. "
         "Urinalysis strongly positive for infection; renal ultrasound confirms findings of acute "
         "right pyelonephritis without obstruction or abscess. Started on IV ceftriaxone; urine "
         "culture pending."),
        ("Past Medical History", ["No significant past medical history"]),
        ("Physical Examination",
         "Vitals: T 38.9 C, HR 108, BP 108/68, RR 18, SpO2 99% RA.\n\n"
         "General: Uncomfortable, ill-appearing. Abdomen: Soft, right costovertebral angle "
         "tenderness, no rebound or guarding. Cardiac: Tachycardic, regular, no murmurs."),
        ("Assessment and Plan",
         "33-year-old female with acute right pyelonephritis without obstruction, hemodynamically "
         "stable, improving on empiric IV antibiotics.\n\n"
         "1. Acute pyelonephritis: IV ceftriaxone 1 g daily; repeat CBC at 24 hours showed "
         "improving leukocytosis with clinical defervescence. Urine culture finalized as E. coli "
         "sensitive to ceftriaxone; plan to transition to an oral agent (cefpodoxime) once "
         "afebrile 24 hours, to complete a 7-day total course. 2. Hydration: IV fluids while NPO "
         "status resolved, encourage oral intake. Disposition: Anticipate discharge on hospital "
         "day 2-3 once afebrile and tolerating oral antibiotics."),
    ]
    sig = ["Electronically signed by: <b>Diego F. Camarena, MD</b> — Hospital Medicine   07/31/2026 15:20 EDT"]
    emit_note(folder, "P015_admission_HP_note.pdf", hosp, P015, nmeta, sections, sig, dx)


# ----------------------------------------------------------------------------
def write_manifest():
    path = os.path.join(OUT_ROOT, "manifest.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["patient_name", "mrn", "dob", "sex", "doc_category", "doc_type",
                    "accession", "encounter", "reported", "diagnosis", "file"])
        for pt, meta, cat, fpath, dx in MANIFEST:
            w.writerow([f"{pt['last']}, {pt['first']}", pt["mrn"], pt["dob"], pt["sex"],
                        cat, meta.get("doctype", meta.get("note_title", "")),
                        meta.get("accession", meta.get("docid", "")),
                        meta["encounter"], meta.get("reported", meta.get("printed", "")),
                        dx, os.path.relpath(fpath, OUT_ROOT)])
    readme = os.path.join(OUT_ROOT, "README.md")
    with open(readme, "w", encoding="utf-8") as f:
        f.write(
            "# Synthetic Clinical PDF Dataset\n\n"
            "All documents in this folder are **fully synthetic**. Institutions, providers, "
            "patients, MRNs, CLIA numbers, and results are fictional and generated for "
            "document-intelligence pipeline development (OCR / extraction / RAG). "
            "They must not be represented as genuine medical records.\n\n"
            "Regenerate with: `python dataset/pdf_generator/generate_hospital_pdfs.py`\n"
        )


def main():
    os.makedirs(OUT_ROOT, exist_ok=True)
    for fn in (case_p001, case_p002, case_p003, case_p004, case_p005,
               case_p006, case_p007, case_p008, case_p009, case_p010,
               case_p011, case_p012, case_p013, case_p014, case_p015):
        fn()
    write_manifest()
    print(f"Generated {len(MANIFEST)} PDFs under {OUT_ROOT}")
    for _, _, cat, fpath, _ in MANIFEST:
        print(f"  [{cat:15s}] {os.path.relpath(fpath, OUT_ROOT)}")


if __name__ == "__main__":
    main()
